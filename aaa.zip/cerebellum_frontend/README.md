# scrub

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 15.2.0.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:9527/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

### What's included

Within the download you'll find the following directories and files.
You'll see something like this:
<!-- app.component.html -->
```
├── .angular/                                         // VS Code Editor Config(VS Code编辑器配置)
├── .vscode/                                          // VS Code Editor Config(VS Code编辑器配置)
├── src/                                              // Project Directory File(项目目录文件)
│   ├── app/                                          // Interface Directory File(接口文件目录)
│   │   ├── components/                               // Component File Directory(组件文件目录)
│   │   │   ├── case/                                 // Case Cluse/Reopen Components
│   │   │   ├── changeHistory/                        // Change HistoryComponents
│   │   │   ├── common/                               // Common Components
│   │   │   ├── control/                              // Control Components
│   │   │   ├── index/                                // Home Components
│   │   │   ├── input/                                // Input Components
│   │   │   ├── layout/                               // Project Framework Components
│   │   │   ├── management/                           // Automation Management Components
│   │   │   ├── menu/                                 // Menu Components
│   │   │   ├── navbar/                               // Navbar Components
│   │   │   ├── pna/                                  // PNA Modelling Components
│   │   │   ├── selfhelp/                             // Self-Help Components
│   │   │   ├── workorder/                            // WO Cancellation Components
│   │   │   ├── index.ts                              // Component Entry File
│   │   ├── helper/                                   // Tool Class Method Folder(工具方法文件夹)
│   │   │   ├── cid.httpintercept.ts                  // Encapsulated Interface Request Method
│   │   │   ├── helper.service.ts                     // Tool Class Method
│   │   │   ├── http.ts                               // Encapsulated Request Method
│   │   ├── service/                                  // Interface Directory File(接口文件目录)
│   │   │   ├── base/                                 // Base Interface File
│   │   │   ├── case/                                 // Case Component Interface File
│   │   │   ├── changeHistory/                        // Change History Component Interface File
│   │   │   ├── control/                              // Control Component Interface File
│   │   │   ├── index/                                // Home Component Interface File
│   │   │   ├── selfhelp/                             // selfhelp Component Interface File
│   │   │   ├── token/                                // Token Interface File
│   │   │   ├── user/                                 // User Interface File
│   │   │   ├── index.ts                              // Interface Entry File
│   │   ├── app-routing.module.ts                     // Router Config File(路由配置文件)
│   │   ├── app.component.html                        // app Page Entry File
│   │   ├── app.component.scss                        // app Entry Style File
│   │   ├── app.component.ts                          // app Entry TypeScript File
│   │   ├── app.module.ts                             // app Entry File
│   ├── assets/                                       // Static Resources(静态资源)
│   ├── style/                                        // Style Folder(样式文件夹)
│   ├── favicon.ico                                   // Project Icon(项目图标)
│   ├── index.html                                    // Project Entry Document(项目入口文件)
│   ├── main.ts                                       // 
│   ├── style.scss                                    // Style Entry Document(样式入口文件)
├── .editorconfig                                     // Editor Config(编辑器配置)
├── .gitignore                                        // Config Ignores Certain File Changes(配置忽略文件)
├── angular.json                                      // Angular CIL Config
├── package-lock.json                                 // package lock File
├── package.json                                      // Project Dependency Package Config(项目依赖包配置)
├── README.md                                         // You Know ~
├── tsconfig.app.json                                 // Config Of TypeScript compiler(TypeScript编译器的配置)
├── tsconfig.json                                     // TypeScript Config For Project
└── tsconfig.spec.json                                // TypeScript Config For Application Testing(用于应用程序测试的TypeScript配置)

```
