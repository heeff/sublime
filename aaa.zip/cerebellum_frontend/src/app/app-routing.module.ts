import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {
  APIFailureDistributionComponent,
  APIHealthDashboardComponent,
  IndexComponent,
  InfraManagementComponent,
  JobManagementComponent,
  ManagementComponent,
  PermissionComponent,
  ReportManagementComponent,
  ServerHealthListComponent,
  SvcAccountComponent,
  VMResourceMonitorComponent,
  VulnerabilityManagementComponent
} from './components';

export const routes: Routes = [
  // UserPage
  { path: '', redirectTo: '/index', pathMatch: 'full' },
  { path: 'index', component: IndexComponent },
  { path: 'sqlJobMonitor', component: JobManagementComponent },
  { path: 'svcAccountMgmt', component: SvcAccountComponent },
  { path: 'apiHealthDashboard', component: APIHealthDashboardComponent },
  { path: 'apiFailureDistribution', component: APIFailureDistributionComponent },
  { path: 'vulnerabilityMgmt', component: VulnerabilityManagementComponent },
  { path: 'serverHealth', component: ServerHealthListComponent },
  { path: 'infraManagement', component: InfraManagementComponent },
  { path: 'vmResourceMonitor', component: VMResourceMonitorComponent },
  { path: 'reportMgmt', component: ReportManagementComponent },

  // ManagementPage
  { path: 'onboard', component: ManagementComponent },
  { path: 'permission', component: PermissionComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
