import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { GlobalService, StorageService, TokenService } from './service';
import { AppComponent } from './app.component';
import { NgxGraphModule } from '@swimlane/ngx-graph';
 
describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });
 
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let tokenServiceMock: jasmine.SpyObj<TokenService>;
  let storageServiceMock: jasmine.SpyObj<StorageService>;
  let globalServiceMock: jasmine.SpyObj<GlobalService>;

 
  beforeEach(async () => {
    // 创建依赖注入服务的模拟对象
    tokenServiceMock = jasmine.createSpyObj('TokenService', ['saveTokenAsync']);
    storageServiceMock = jasmine.createSpyObj('StorageService', ['getData']);
    globalServiceMock = jasmine.createSpyObj('GlobalService', ['sendMessage']);
 
    await TestBed.configureTestingModule({
      declarations: [ AppComponent ],
      imports:[NgxGraphModule],
      providers: [
        { provide: TokenService, useValue: tokenServiceMock },
        { provide: StorageService, useValue: storageServiceMock },
        { provide: GlobalService, useValue: globalServiceMock },
      ]
    }).compileComponents();
  });
 
  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
 
  it('should create the app', () => {
    expect(component).toBeTruthy();
  });
 
 
  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });
 
  it(`should have as title 'Cerebellum`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('Cerebellum');
  });
});
 