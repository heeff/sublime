import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GlobalService, StorageService, TokenService, UserService } from './service';
import { LayoutComponent } from './components';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  imports: [CommonModule, LayoutComponent, NzSpinModule, NzCardModule, NzIconModule]
})

export class AppComponent implements OnInit {
  _globalSubscription!: Subscription;

  title = 'Cerebellum';
  userInfo: any = {};
  loading: boolean = false;

  constructor(
    private globalService: GlobalService,
    private tokenService: TokenService,
    private storageService: StorageService,
    private userService: UserService,
  ) {
  }

  ngOnDestroy() {
    this._globalSubscription.unsubscribe();
  }

  async ngOnInit() {
    this.loading = true
    let token: any = this.storageService.getData('token')
    try {
      token = await this.tokenService.saveTokenAsync();
    } catch (error) {
      token = await this.tokenService.saveTokenAsync();
    }
    if (token === '') return
    this.queryUserInfo()
  }

  queryUserInfo() {
    this.userService.getUserInfo().then((res: any) => {
      let data = res.data
      this.userInfo = data
      if (!data) {
        this.loading = false
        return
      }
      this.storageService.setData('userInfo', JSON.stringify(data))
      this.loading = false
    }).catch((error: any) => {
      console.log(error)
    })
  }

  // async handleLogin() {
  //   this.loading = true
  //   try {
  //     this.token = await this.tokenService.saveTokenAsync();
  //     this.loading = false
  //   } catch (error) {
  //     this.handleLogin()
  //   }
  // }

}
