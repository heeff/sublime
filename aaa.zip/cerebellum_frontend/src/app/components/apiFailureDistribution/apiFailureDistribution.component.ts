import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { APIFailureListComponent } from './apiFailureList.component';
import { APIFailureBreakdownComponent } from './apiFailureBreakdown.component';

@Component({
  selector: 'app-apiFailureDistribution',
  templateUrl: './apiFailureDistribution.component.html',
  styleUrls: ['./apiFailureDistribution.component.scss'],
  imports: [
    CommonModule,
    NzGridModule,
    NzIconModule,
    NzButtonModule,
    NzTabsModule,
    APIFailureListComponent,
    APIFailureBreakdownComponent
  ],
})
export class APIFailureDistributionComponent implements OnInit {
  selectedIndex = 0;
  info: any = {};

  constructor(
  ) { }

  ngOnInit() {
  }

  handleAPIDetail(values: any) {
    this.selectedIndex = 0
    this.info = values
  }
}