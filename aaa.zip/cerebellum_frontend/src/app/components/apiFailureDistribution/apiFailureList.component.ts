import { Component, OnInit, ChangeDetectorRef, inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { HealthService } from '../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { APITypeOptions, ExecutionAgeOptions } from 'src/app/util/constant';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { UTCToLocalPipe } from 'src/app/helper/utcto-local.pipe';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { getColorForErrorCode } from 'src/app/util';

@Component({
  selector: 'app-api-failure-list',
  templateUrl: './apiFailureList.component.html',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzGridModule,
    NzFormModule,
    FormsModule,
    NzTableModule,
    NzPaginationModule,
    NzInputModule,
    NzIconModule,
    NzButtonModule,
    NzSelectModule,
    NzTooltipModule,
    UTCToLocalPipe,
    NzTagModule
  ],
})
export class APIFailureListComponent implements OnInit {
  @Input() info: any = {};

  private fb = inject(NonNullableFormBuilder);
  validateForm = this.fb.group({
    execution_age: this.fb.control(['10-15s']),
    api_type: this.fb.control('Owned API'),
    api_name: this.fb.control<string[]>([])
  });
  tableData: any = {
    list: [],
    pageNum: 1,
    pageSize: 20,
    total: 100
  };
  loading: boolean = true
  executionAgeOptions: any = ExecutionAgeOptions
  apiTypeOptions: any = APITypeOptions
  apiNameOptions: any = []
  allAPINameOptions: any = []
  errorCodeColorMap: Map<string, string> = new Map() // 存储每个 error code 对应的颜色

  constructor(private healthService: HealthService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.queryAPINameList()
  }

  ngOnChanges(changes: any): void {
    if (changes.info && changes.info.currentValue) {
      if (changes.info.currentValue.API_Function) {
        this.tableData.list = []
        let ary = []
        ary.push(changes.info.currentValue.API_Function)
        this.validateForm.patchValue({
          execution_age: [],
          api_type: '',
          api_name: ary
        })
        this.apiNameOptions = this.allAPINameOptions
        this.loading = true
        this.tableData.pageNum = 1
        this.queryList()
      }
    }
  }

  async queryAPINameList() {
    this.healthService.getFilterAPINameByTypeOptionsList({
      category_name: 'Ping_Overdue'
    }).then((res: any) => {
      this.allAPINameOptions = res.data
      this.filterAPIName()
      this.queryList()
    }).catch((error: any) => {
      this.loading = false
      this.message.error(error.message);
    })
  }

  filterAPIName() {
    this.apiNameOptions = this.allAPINameOptions.filter((item: any) => item.api_type === this.validateForm.get('api_type')?.value)
  }

  async queryList() {
    this.healthService.getPingOverdueList({
      page_size: this.tableData.pageSize,
      page_num: this.tableData.pageNum,
      ...this.validateForm.value
    }).then((res: any) => {
      const data = res.data.data || []
      data.forEach((code: string) => {
        if (!this.errorCodeColorMap.has(code)) {
          this.errorCodeColorMap.set(code, getColorForErrorCode(code))
        }
      })
      this.tableData.list = res.data.data || []
      this.tableData.total = res.data.total_count
      this.cdr.markForCheck();
      this.loading = false
    }).catch((error: any) => {
      this.message.error(error.message);
      this.loading = false
    })
  }

  //  根据 error code 获取颜色
  getColor(code: string): string {
    return this.errorCodeColorMap.get(code) || '#108ee9' // 默认蓝色
  }

  handleSearch() {
    this.loading = true
    this.tableData.pageNum = 1
    this.queryList()
  }

  handlePageIndexChange(page: number) {
    this.loading = true
    this.tableData.pageNum = page
    this.queryList()
  }

  handleReset() {
    this.loading = true
    this.validateForm.reset()
    this.tableData.pageNum = 1
    this.queryList()
  }
}