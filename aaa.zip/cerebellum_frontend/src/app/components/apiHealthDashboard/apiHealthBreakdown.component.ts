import { ChangeDetectorRef, Component, EventEmitter, inject, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule } from '@angular/forms';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { APITypeOptions, Threshold } from 'src/app/util/constant';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { HealthService } from 'src/app/service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { NzTagModule } from 'ng-zorro-antd/tag';

@Component({
  selector: 'app-health-breakdown',
  templateUrl: './apiHealthBreakdown.component.html',
  imports: [
    CommonModule,
    NzGridModule,
    NzIconModule,
    NzButtonModule,
    ReactiveFormsModule,
    NzFormModule,
    FormsModule,
    NzSelectModule,
    NzPaginationModule,
    NzSpinModule,
    NzTooltipModule,
    NzPopoverModule,
    NzTagModule
  ],
})
export class APIHealthBreakdownComponent implements OnInit {
  @Output() apiDetailEmit = new EventEmitter<boolean>();

  private fb = inject(NonNullableFormBuilder);
  validateForm = this.fb.group({
    api_name: this.fb.control([]),
    api_type: this.fb.control(''),
    is_abnormal: this.fb.control(''),
  });
  allAPINameOptions: any = []
  apiNameOptions: any = []
  apiTypeOptions: any = APITypeOptions
  data: any = {
    list: [],
    pageNum: 1,
    pageSize: 16,
    total: 0
  }
  threshold = Threshold
  loading: boolean = true

  constructor(
    private healthService: HealthService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.queryAPINameList()
  }

  async queryAPINameList() {
    this.healthService.getAPINameOptionsList().then((res: any) => {
      this.allAPINameOptions = res.data
      this.apiNameOptions = this.allAPINameOptions
      this.queryList()
    }).catch((error: any) => {
      this.loading = false
      this.message.error(error.message);
    })
  }

  filterAPIName() {
    this.validateForm.get('api_name')?.setValue([])
    this.apiNameOptions = this.allAPINameOptions.filter((item: any) => item.API_Type === this.validateForm.get('api_type')?.value)
  }

  queryList() {
    this.loading = true
    this.healthService.getAPIBreakdownList({
      page_size: this.data.pageSize,
      page_num: this.data.pageNum,
      category_name: 'Error_Code',
      ...this.validateForm.value
    }).then((res: any) => {
      this.data.list = res.data.data || []
      this.data.total = res.data.total_count
      this.cdr.markForCheck();
      this.loading = false
    }).catch((error: any) => {
      this.message.error(error.message);
      this.loading = false
    })
  }

  handleAPIDetail(values: any) {
    this.apiDetailEmit.emit(values)
  }

  handleSearch() {
    this.data.pageNum = 1
    this.queryList()
  }

  handlePageIndexChange(page: number) {
    this.data.pageNum = page
    this.queryList()
  }

  handleReset() {
    this.validateForm.reset()
    this.data.pageNum = 1
    this.apiNameOptions = this.allAPINameOptions
    this.queryList()
  }
}