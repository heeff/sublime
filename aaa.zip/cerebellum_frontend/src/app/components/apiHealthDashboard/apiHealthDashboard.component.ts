import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { APIHealthListComponent } from './apiHealthList.component';
import { APIHealthBreakdownComponent } from './apiHealthBreakdown.component';

@Component({
  selector: 'app-health-dashboard',
  templateUrl: './apiHealthDashboard.component.html',
  styleUrls: ['./apiHealthDashboard.component.scss'],
  imports: [
    CommonModule,
    NzGridModule,
    NzIconModule,
    NzButtonModule,
    NzTabsModule,
    APIHealthListComponent,
    APIHealthBreakdownComponent
  ],
})
export class APIHealthDashboardComponent implements OnInit {
  selectedIndex = 0;
  info: any = {};

  constructor(
  ) { }

  ngOnInit() {
  }

  handleAPIDetail(values: any) {
    this.selectedIndex = 0
    this.info = values
  }

}