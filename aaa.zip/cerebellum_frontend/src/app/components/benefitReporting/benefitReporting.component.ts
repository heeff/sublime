import { Component, Input } from '@angular/core';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { SavingComponent } from './saving.component';
import { BenefitViewChartComponent } from './benefitViewChart.component';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { BenefitTabList } from 'src/app/util/constant';
import { BenefitTableComponent } from './benefitTable.component';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { HealthService } from 'src/app/service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { UTCToLocalPipe } from 'src/app/helper/utcto-local.pipe';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-benefitReporting',
  imports: [
    CommonModule,
    NzGridModule,
    NzSelectModule,
    NzTabsModule,
    NzButtonModule,
    NzSpinModule,
    SavingComponent,
    BenefitViewChartComponent,
    BenefitTableComponent,
    UTCToLocalPipe
  ],
  templateUrl: './benefitReporting.component.html',
  styleUrl: './benefitReporting.component.scss',
  standalone: true
})
export class BenefitReportingComponent {
  @Input() reportIndex: number = 0;

  tabList = BenefitTabList
  selectedTabIndex = 0
  visible: boolean = false
  chartData:any = {}

  constructor(
    private healthService: HealthService,
    private message: NzMessageService,
  ) { }

  ngOnChanges(changes: any): void {
    if (changes.selectIndex) {
      this.selectedTabIndex = changes.selectIndex.currentValue;
    }
  }

  ngOnInit() {
    this.queryReportChart()
  }

  queryReportChart(){
    this.healthService.getReportChart({
      chart_type:this.selectedTabIndex === 0 ? 'Weekly_&_Daily':'Quarterly_&_Monthly',
      report_name:this.reportIndex === 0 ? 'Troubleshooting_Effectiveness':'DummyTag_Cancellation',
    }).then((res:any) => {
      this.chartData = res.data
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    })
  }

  handleTabChange(selectedTabIndex: number) {
    this.selectedTabIndex = selectedTabIndex
    this.queryReportChart()
  }
}
