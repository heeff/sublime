import { Component, Input } from '@angular/core';
import { NgxEchartsModule } from 'ngx-echarts';
import * as echarts from 'echarts';

@Component({
  selector: 'app-benefitViewChart',
  imports: [
    NgxEchartsModule,
  ],
  template: `
    <div class="chart-container">
      <div
        echarts
        [options]="chartOption"
        (chartInit)="onChartInit($event)"
        class="report-chart"
        style="width: 100%; height: 300px;">
      </div>
    </div>
  `,
  styleUrl: './benefitReporting.component.scss',
  standalone: true
})
export class BenefitViewChartComponent {
  @Input() info: number = 0;
  @Input() chartData: any = {};

  echartsInstance: any;
  chartOption: echarts.EChartsOption = {};

  constructor(
  ) { }

  ngOnChanges(changes: any): void {
    if (changes.chartData) {
      this.updateChartData()
    }
  }

  onChartInit(echart: any) {
    this.echartsInstance = echart;
  }

  updateChartData() {
    const chartData = this.chartData.chartData
    if (chartData?.length === 0) return;
    const dates = chartData.map((item: any) => item.date);
    const failedCount = chartData.map((item: any) => item['FailedCount#']);
    const attainment = chartData.map((item: any) => item.Attainment);

    this.chartOption = {
      title: {
        text: this.info === 0 ? 'Weekly & Daily View' : 'Quarterly & Monthly View',
        left: 'center',
        textStyle: {
          color: '#333',
          fontSize: 18
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross'
        },
      },
      legend: {
        bottom: 0,
        left: 'center',
        data: ['Failed Count#', 'Attainment %'],
      },
      grid: {
        left: '3%',
        right: '3%',
        bottom: '10%',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: dates,
          axisPointer: {
            type: 'shadow'
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          position: 'left',
          axisLabel: {
            formatter: '{value}'
          }
        },
        {
          type: 'value',
          position: 'right',
          axisLabel: {
            formatter: '{value} %'
          }
        }
      ],
      series: [
        {
          name: 'Failed Count#',
          type: 'bar',
          data: failedCount,
          itemStyle: {
            color: '#83bff6'
          },
          emphasis: {
            itemStyle: {
              color: '#83bff6'
            }
          }
        },
        {
          name: 'Attainment %',
          type: 'line',
          yAxisIndex: 1,
          data: attainment,
          label: {
            show: true,   
            position: 'top', 
            formatter: '{c} %'  
          },
          itemStyle: {
            color: '#ff6b6b'
          },
          lineStyle: {
            width: 3,
            type: 'solid'
          },
          symbol: 'circle',
          symbolSize: 8,
          smooth: true
        }
      ]
    };
  }
}
