import { Component } from '@angular/core';
import { NgxEchartsModule } from 'ngx-echarts';
import * as echarts from 'echarts';

@Component({
  selector: 'app-dummytag',
  imports: [NgxEchartsModule],
  template: `
    <div class="chart-container">
      <div
        echarts
        [options]="chartOption"
        class="report-chart"
        (chartInit)="onChartInit($event)"
        style="width: 100%; height: 100%;">
      </div>
    </div>
  `,
  styleUrl: './benefitReporting.component.scss',
  standalone: true
})
export class DummyTagComponent {
  chartOption: echarts.EChartsOption = {
    title: {
      text: 'Saving (Design)',
      left: 'center',
      textStyle: {
        color: '#333',
        fontSize: 18
      }
    },
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
      bottom: 10,
      left: 'center',
      data: ['CityA', 'CityB']
    },
    series: [
      {
        type: 'pie',
        radius: '65%',
        center: ['50%', '50%'],
        selectedMode: 'single',
        data: [
          // {
          //     value: 1548,
          //     name: 'CityE',
          //     label: {
          //         formatter: [
          //             '{title|{b}}{abg|}',
          //             '  {weatherHead|Weather}{valueHead|Days}{rateHead|Percent}',
          //             '{hr|}',
          //             '  {Sunny|}{value|202}{rate|55.3%}',
          //             '  {Cloudy|}{value|142}{rate|38.9%}',
          //             '  {Showers|}{value|21}{rate|5.8%}'
          //         ].join('\n'),
          //         backgroundColor: '#eee',
          //         borderColor: '#777',
          //         borderWidth: 1,
          //         borderRadius: 4,
          //         rich: {
          //             title: {
          //                 color: '#eee',
          //                 align: 'center'
          //             },
          //             abg: {
          //                 backgroundColor: '#333',
          //                 width: '100%',
          //                 align: 'right',
          //                 height: 25,
          //                 borderRadius: [4, 4, 0, 0]
          //             },
          //             Sunny: {
          //                 height: 30,
          //                 align: 'left',
          //                 backgroundColor: {
          //                     image: weatherIcons.Sunny
          //                 }
          //             },
          //             Cloudy: {
          //                 height: 30,
          //                 align: 'left',
          //                 backgroundColor: {
          //                     image: weatherIcons.Cloudy
          //                 }
          //             },
          //             Showers: {
          //                 height: 30,
          //                 align: 'left',
          //                 backgroundColor: {
          //                     image: weatherIcons.Showers
          //                 }
          //             },
          //             weatherHead: {
          //                 color: '#333',
          //                 height: 24,
          //                 align: 'left'
          //             },
          //             hr: {
          //                 borderColor: '#777',
          //                 width: '100%',
          //                 borderWidth: 0.5,
          //                 height: 0
          //             },
          //             value: {
          //                 width: 20,
          //                 padding: [0, 20, 0, 30],
          //                 align: 'left'
          //             },
          //             valueHead: {
          //                 color: '#333',
          //                 width: 20,
          //                 padding: [0, 20, 0, 30],
          //                 align: 'center'
          //             },
          //             rate: {
          //                 width: 40,
          //                 align: 'right',
          //                 padding: [0, 10, 0, 0]
          //             },
          //             rateHead: {
          //                 color: '#333',
          //                 width: 40,
          //                 align: 'center',
          //                 padding: [0, 10, 0, 0]
          //             }
          //         }
          //     }
          // },
          // { value: 735, name: 'CityC' },
          // { value: 510, name: 'CityD' },
          { value: 434, name: 'CityB' },
          { value: 335, name: 'CityA' }
        ],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]

  };

  // ECharts 实例
  echartsInstance: any;

  // 图表初始化完成回调
  onChartInit(echarts: any): void {
    this.echartsInstance = echarts;
  }

}
