import { Component } from '@angular/core';
import { NgxEchartsModule } from 'ngx-echarts';
import * as echarts from 'echarts';

@Component({
  selector: 'app-duplicated-part',
  imports: [NgxEchartsModule],
  template: `
    <div class="chart-container">
      <div
        echarts
        [options]="chartOption"
        class="report-chart"
        (chartInit)="onChartInit($event)"
        style="width: 100%; height: 100%;">
      </div>
    </div>
  `,
  styleUrl: './benefitReporting.component.scss',
  standalone: true
})
export class DuplicatedPartComponent {
  chartOption: echarts.EChartsOption = {
    title: {
      text: 'Duplicated Part Review (Design)',
      left: 'center',
      textStyle: {
        color: '#333',
        fontSize: 18
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross'
      }
    },
    legend: {
      // data: ['Smart ID Review', 'Fraud Details'],
      top: 40
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        data: ['2026-W44', '2026-W45', '2026-W46', '2026-W47', '2026-W48', '2026-W49'],
        axisPointer: {
          type: 'shadow'
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        // name: 'Smart ID Review',
        position: 'left',
        axisLabel: {
          formatter: '{value}'
        }
      },
      {
        type: 'value',
        // name: 'Fraud Details',
        position: 'right',
        axisLabel: {
          formatter: '{value}'
        }
      }
    ],
    series: [
      {
        // name: 'Smart ID Review',
        type: 'bar',
        data: [190, 170, 125, 167, 95, 235],
        itemStyle: {
          // color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          //   { offset: 0, color: '#83bff6' },
          //   { offset: 0.5, color: '#188df0' },
          //   { offset: 1, color: '#188df0' }
          // ])
          color: '#1fab89'
        },
        emphasis: {
          itemStyle: {
            // color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            //   { offset: 0, color: '#2378f7' },
            //   { offset: 0.7, color: '#2378f7' },
            //   { offset: 1, color: '#83bff6' }
            // ])
            color: '#1fab89'
          }
        }
      },
      {
        // name: 'Fraud Details',
        type: 'line',
        yAxisIndex: 1,
        data: [6.4, 3.0, 2.9, 3.0, 4.2, 5.3],
        itemStyle: {
          color: '#ff6b6b'
        },
        lineStyle: {
          width: 3,
          type: 'solid'
        },
        symbol: 'circle',
        symbolSize: 8,
        smooth: true
      }
    ]
  };

  // ECharts 实例
  echartsInstance: any;

  // 图表初始化完成回调
  onChartInit(echarts: any): void {
    this.echartsInstance = echarts;
  }

}
