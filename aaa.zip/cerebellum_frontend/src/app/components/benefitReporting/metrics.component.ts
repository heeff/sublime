import { Component, OnInit } from '@angular/core';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NgxEchartsModule } from 'ngx-echarts';
import { ReportService } from 'src/app/service';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzButtonModule } from 'ng-zorro-antd/button';
import * as echarts from 'echarts';

@Component({
  selector: 'app-report-metrics',
  imports: [
    FormsModule,
    NgxEchartsModule,
    NzFormModule,
    NzSelectModule,
    NzTabsModule,
    ReactiveFormsModule,
    NzSwitchModule,
    NzButtonModule
  ],
  providers: [ReportService],
  template: `
    <div class="select-container">
      <div class="select-item-container">
        <label class="select-label">Applications: </label>
        <nz-select
          [nzMaxTagCount]="2"
          nzMode="multiple"
          nzAllowClear
          [(ngModel)]="selectedProjectValue"
          style="min-width: 150px;"
        >
          @for (item of applications; track item) {
            <nz-option [nzLabel]="item" [nzValue]="item"></nz-option>
          }
        </nz-select>
      </div>
      <div class="select-item-container">
        <!-- <label class="select-label">Use Period?</label> -->
        <nz-switch [(ngModel)]="usePeriod" nzCheckedChildren="Monthly View" nzUnCheckedChildren="Sprint View"></nz-switch>
      </div>
      @if (usePeriod) {
        <div class="select-item-container">
          <label class="select-label">Monthly View: </label>
          <nz-select
            [nzMaxTagCount]="1"
            nzMode="default"
            nzAllowClear
            [(ngModel)]="currentDate"
            style="min-width: 150px;"
          >
            @for (item of dates; track item) {
              <nz-option [nzLabel]="item" [nzValue]="item"></nz-option>
            }
          </nz-select>
        </div>
      } @else {
        <div class="select-item-container">
          <label class="select-label">Sprint View: </label>
          <nz-select
            [nzMaxTagCount]="3"
            nzMode="multiple"
            nzAllowClear
            [(ngModel)]="currentSprint"
            style="min-width: 220px;"
          >
            @for (item of sprintData; track item) {
              <nz-option [nzLabel]="item.name" [nzValue]="item.id"></nz-option>
            }
          </nz-select>
        </div>
      }
      <div class="select-item-container">
         <button nz-button nzType="primary" (click)="applySeach()" [nzLoading]="isApplyLoading">Apply</button>
      </div>
    </div>
    <div class="tab-container">
      <nz-tabs>
        <nz-tab nzTitle="Jira Story Point">
          <div class="report-container">
            <div
              echarts
              [options]="chartStoryPointOption"
              class="report-chart"
              (chartInit)="onStoryPointChartInit($event)"
              style="width: 100%; height: 100%;"
            ></div>
          </div>
        </nz-tab>
        <nz-tab nzTitle="Jira Story Count">
          <div class="report-container">
            <div
              echarts
              [options]="chartStoryCountOption"
              class="report-chart"
              (chartInit)="onStoryCountChartInit($event)"
              style="width: 100%; height: 100%;"
            ></div>
          </div>
        </nz-tab>
      </nz-tabs>
    </div>
  `,
  styleUrl: './benefitReporting.component.scss',
  standalone: true,
})
export class MetricsComponent implements OnInit {
  isApplyLoading: boolean = false;
  usePeriod: boolean = true;
  reportData: any;
  yAxisData: string[] = [];
  yAxisData2: string[] = [];
  storyCountData: number[] = [];
  storyPointData: number[] = [];
  storyPointPlannedData: number[] = [];
  storyPointAssignedData: number[] = [];
  sprintData: any[] = [];
  currentSprint: any[] = [];
  dates: string[] = this.getDatesString();
  applications: string[] = ['AI_Validated_Dispatch', 'AIVD_Cerebellum', 'AIVD_SysExg_CRE_Validation'];
  currentDate: string = this.getCurrentDateString();
  currentApplication: string = this.applications[0];
  result: any = {
    user: [],
    storyPoint: [],
    storyPlaned: [],
    storyAssigned: []
  };
  result2: any = {
    user: [],
    storyCount: [],
  };
  selectedProjectValue: string[] = ['AI_Validated_Dispatch', 'AIVD_Cerebellum', 'AIVD_SysExg_CRE_Validation'];

  constructor(private reportService: ReportService) { }

  async ngOnInit() {
    let result = await this.reportService.sprintList();
    this.sprintData = result.data;
    await this.updateData();
  }

  cleadData() {
    this.yAxisData = [];
    this.yAxisData2 = [];
    this.storyCountData = [];
    this.storyPointData = [];
    this.storyPointPlannedData = [];
    this.storyPointAssignedData = [];
    this.result = {
      user: [],
      storyPoint: [],
      storyPlaned: [],
      storyAssigned: []
    };
    this.result2 = {
      user: [],
      storyCount: [],
    };
  }

  async updateData() {
    this.cleadData();
    this.reportData = this.usePeriod ?
      await this.reportService.getReport(
        this.currentDate,
        this.selectedProjectValue,
      )
      :
      await this.reportService.getReportBySprint(
        this.currentSprint,
        this.selectedProjectValue
      );

    let storyPointData = this.getStoryPointData(this.reportData.data);
    let storyCountData = this.getStoryCountData(this.reportData.data);

    this.getStoryPointResult(storyPointData);
    this.getStoryCountResult(storyCountData);

    this.yAxisData = this.result.user;

    this.storyPointData = this.result.storyPoint;
    this.storyPointPlannedData = this.result.storyPlaned;
    this.storyPointAssignedData = this.result.storyAssigned;

    this.yAxisData2 = this.result2.user;
    this.storyCountData = this.result2.storyCount;
    const currentDate = this.getCurrentDateString();
    if (this.storyPointInstance) {
      this.storyPointInstance.clear();
    }
    if (this.currentDate === currentDate) {
      this.storyPointInstance.setOption({
        title: {
          text: 'Jira Task Tracking',
          left: 'center',
          textStyle: {
            color: '#333',
            fontSize: 18,
          },
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
          },
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        legend: {
          data: ['Story Points', 'Story Points Planned', 'Story Points Assigned'],
          top: 40,
        },
        xAxis: [
          {
            type: 'value',
            position: 'right',
            axisLabel: {
              formatter: '{value}',
            },
          },
        ],
        yAxis: [
          {
            type: 'category',
            data: this.yAxisData,
            axisPointer: {
              type: 'shadow',
            },
          },
        ],
        series: [
          {
            name: 'Story Points',
            type: 'bar',
            data: this.storyPointData,
            stack: 'total',
            itemStyle: {
              color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                { offset: 0, color: '#83bff6' },
                { offset: 0.5, color: '#188df0' },
                { offset: 1, color: '#188df0' },
              ]),
            },
            emphasis: {
              itemStyle: {
                color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                  { offset: 0, color: '#83bff6' },
                  { offset: 0.5, color: '#188df0' },
                  { offset: 1, color: '#188df0' },
                ]),
              },
            },
          },
          {
            name: 'Story Points Assigned',
            type: 'bar',
            data: this.storyPointAssignedData,
            stack: 'total',
            itemStyle: {
              color: '#e6e6e6',
            },
            emphasis: {
              itemStyle: {
                color: '#e6e6e6',
              },
            },
          },
          {
            name: 'Story Points Planned',
            type: 'bar',
            data: this.storyPointPlannedData,
            stack: 'total',
            itemStyle: {
              color: '#f4f4f4',
            },
            emphasis: {
              itemStyle: {
                color: '#f4f4f4',
              },
            },
          },
        ],
      });
    } else {
      this.storyPointInstance.setOption({
        title: {
          text: 'Jira Task Tracking',
          left: 'center',
          textStyle: {
            color: '#333',
            fontSize: 18,
          },
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
          },
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        legend: {
          data: ['Story Points', 'Story Points Assigned'],
          top: 40,
        },
        xAxis: [
          {
            type: 'value',
            position: 'right',
            axisLabel: {
              formatter: '{value}',
            },
          },
        ],
        yAxis: [
          {
            type: 'category',
            data: this.yAxisData,
            axisPointer: {
              type: 'shadow',
            },
          },
        ],
        series: [
          {
            name: 'Story Points',
            type: 'bar',
            data: this.storyPointData,
            stack: 'total',
            itemStyle: {
              color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                { offset: 0, color: '#83bff6' },
                { offset: 0.5, color: '#188df0' },
                { offset: 1, color: '#188df0' },
              ]),
            },
            emphasis: {
              itemStyle: {
                color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                  { offset: 0, color: '#83bff6' },
                  { offset: 0.5, color: '#188df0' },
                  { offset: 1, color: '#188df0' },
                ]),
              },
            },
          },
          {
            name: 'Story Points Assigned',
            type: 'bar',
            data: this.storyPointAssignedData,
            stack: 'total',
            itemStyle: {
              color: '#e6e6e6',
            },
            emphasis: {
              itemStyle: {
                color: '#e6e6e6',
              },
            },
          },
        ],
      });
    }

    this.storyCountInstance.setOption({
      yAxis: [
        {
          type: 'category',
          data: this.yAxisData2,
          axisPointer: {
            type: 'shadow',
          },
        },
      ],
      series: [
        {
          name: 'Story Count',
          type: 'bar',
          data: this.storyCountData,
          itemStyle: {
            color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
              { offset: 0, color: '#83bff6' },
              { offset: 0.5, color: '#188df0' },
              { offset: 1, color: '#188df0' },
            ]),
          },
          emphasis: {
            itemStyle: {
              color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                { offset: 0, color: '#83bff6' },
                { offset: 0.5, color: '#188df0' },
                { offset: 1, color: '#188df0' },
              ]),
            },
          },
        },
      ],
    });
  }

  getDatesString() {
    const dates = [];
    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth();

    for (let i = 0; i < 12; i++) {
      let prevMonth: number = month - i;
      let prevYear: number = year;
      if (prevMonth < 0) {
        prevYear--;
        prevMonth += 12;
      }
      const prevDate = `${prevYear}${(prevMonth + 1).toString().padStart(2, '0')}`;
      if (prevYear >= 2026) dates.push(prevDate);
    }

    return dates;
  }

  getCurrentDateString() {
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    return `${year}${month}`;
  }

  getStoryPointData(jiraData: any) {
    const result: any = [];

    jiraData.task_chart.sort((a: any, b: any) => a.story_point_done - b.story_point_done);

    jiraData.task_chart.forEach((task: any) => {
      const existingUser = result.find(
        (user: any) => user.user === task.assignee,
      );
      if (existingUser) {
        existingUser.storyPoint += task.story_points;
      } else {
        const currentDate = this.getCurrentDateString()
        if (this.currentDate === currentDate) {
          result.push({
            user: task.assignee,
            storyPoint: task.story_point_done,
            storyPlaned: task.story_point_planned,
            storyAssigned: task.story_point_assigned
          });
        } else {
          result.push({
            user: task.assignee,
            storyPoint: task.story_point_done,
            storyAssigned: task.story_point_assigned
          });
        }
      }
    });

    return result;
  }

  getStoryCountData(jiraData: any) {
    const result: any = [];

    jiraData.story_chart.sort((a: any, b: any) => a.story_count - b.story_count);

    jiraData.story_chart.forEach((story: any) => {
      const existingUser = result.find(
        (user: any) => user.user === story.assignee,
      );
      if (existingUser) {
        existingUser.storyCount += story.story_count;
      } else {
        result.push({
          user: story.assignee,
          storyCount: story.story_count,
        });
      }
    });

    return result;
  }

  getStoryPointResult(step1Data: any[]) {
    step1Data.forEach((user: any) => {
      this.result.user.push(user.user);
      this.result.storyPoint.push(user.storyPoint);
      this.result.storyPlaned.push(user.storyPlaned);
      this.result.storyAssigned.push(user.storyAssigned);
    });
  }

  getStoryCountResult(step1Data: any[]) {
    step1Data.forEach((user: any) => {
      this.result2.user.push(user.user);
      this.result2.storyCount.push(user.storyCount);
    });
  }

  async applySeach() {
    this.isApplyLoading = true;
    await this.updateData();
    this.isApplyLoading = false;
  }

  chartStoryPointOption: echarts.EChartsOption = {
    title: {
      text: 'Jira Task Tracking',
      left: 'center',
      textStyle: {
        color: '#333',
        fontSize: 18,
      },
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
      },
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true,
    },
    xAxis: [
      {
        type: 'value',
        position: 'right',
        axisLabel: {
          formatter: '{value}',
        },
      },
    ],
    yAxis: [
      {
        type: 'category',
        data: this.yAxisData2,
        axisPointer: {
          type: 'shadow',
        },
      },
    ],
    series: [
      {
        name: 'Story Count',
        type: 'bar',
        data: this.storyCountData,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
            { offset: 0, color: '#83bff6' },
            { offset: 0.5, color: '#188df0' },
            { offset: 1, color: '#188df0' },
          ]),
        },
        emphasis: {
          itemStyle: {
            color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
              { offset: 0, color: '#83bff6' },
              { offset: 0.5, color: '#188df0' },
              { offset: 1, color: '#188df0' },
            ]),
          },
        },
      },
    ],
  };

  chartStoryCountOption: echarts.EChartsOption = {
    title: {
      text: 'Jira Task Tracking',
      left: 'center',
      textStyle: {
        color: '#333',
        fontSize: 18,
      },
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
      },
    },
    legend: {
      data: ['Story Count'],
      top: 40,
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true,
    },
    xAxis: [
      {
        type: 'value',
        position: 'right',
        axisLabel: {
          formatter: '{value}',
        },
      },
    ],
    yAxis: [
      {
        type: 'category',
        data: this.yAxisData2,
        axisPointer: {
          type: 'shadow',
        },
      },
    ],
    series: [
      {
        name: 'Story Count',
        type: 'bar',
        data: this.storyCountData,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
            { offset: 0, color: '#83bff6' },
            { offset: 0.5, color: '#188df0' },
            { offset: 1, color: '#188df0' },
          ]),
        },
        emphasis: {
          itemStyle: {
            color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
              { offset: 0, color: '#83bff6' },
              { offset: 0.5, color: '#188df0' },
              { offset: 1, color: '#188df0' },
            ]),
          },
        },
      },
    ],
  };

  // ECharts 实例
  storyPointInstance: any;
  storyCountInstance: any;

  onStoryPointChartInit(echarts: any): void {
    this.storyPointInstance = echarts;
  }

  onStoryCountChartInit(echarts: any): void {
    this.storyCountInstance = echarts;
  }
}
