import { Component, Input } from '@angular/core';
import { NgxEchartsModule } from 'ngx-echarts';
import * as echarts from 'echarts';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-saving',
    imports: [NgxEchartsModule,CommonModule],
    template: `
    <div class="chart-container saving-container">
        <div class="chart-header">
            <div class="chart-header-title" *ngIf="type === 'Home'">AIVD Saving Distribution(Design)</div>
            <div class="chart-header-item" [style]="type === 'Report' ? 'padding-top:10px' : ''">
                <div class="chart-header-label">Total Module</div>
                <div class="chart-header-value">NA</div>
            </div>
        </div>
        <div echarts [options]="chartOption" class="report-chart" (chartInit)="onChartInit($event)"
            style="width: 100%; height: 170px;">
        </div>
    </div>
  `,
    styleUrl: './benefitReporting.component.scss',
    standalone: true
})
export class SavingComponent {
    @Input() info: any = {};
    @Input() type: string='Home';

    savingData: any = [{
        quota: 23,
        attainment: 77,
        type: 'wk'
    }, {
        quota: 42,
        attainment: 58,
        type: 'qm'
    }]

    chartOption: echarts.EChartsOption = {};

    // ECharts 实例
    echartsInstance: any;

    ngOnChanges(changes: any): void {
        if (changes.info) {
            this.updateChartData();
        }
    }

    ngOnInit() {
        this.updateChartData();
    }

    onChartInit(echart: any) {
        this.echartsInstance = echart;
    }

    updateChartData() {
        const data = this.info === 0
            ? this.savingData.filter((item: any) => item.type === 'wk')
            : this.savingData.filter((item: any) => item.type === 'qm');
        this.chartOption = {
            tooltip: {
                trigger: 'item',
                axisPointer: {
                    type: 'shadow'
                },
                formatter: (params: any) => {
                    const { name, value, percent } = params;
                    return `
      <div style="background:#f0f2f5;border-radius:6px;padding:8px;font-size:12px;">
        <div style="font-weight:bold;">${name}</div>
        <div>Proportion：${value}%</div>
      </div>
    `;
                },
                backgroundColor: 'transparent',
                textStyle: {
                    color: '#333'
                },
                extraCssText: 'border:none;'
            },

            legend: {
                bottom: 10,
                left: 'center',
                data: ['quota', 'attainment']
            },
            grid: {
                left: '15%',
                right: '10%',
                top: '15%',
                bottom: '20%',
                containLabel: true
            },
            xAxis: [
                {
                    type: 'value',
                    show: false,
                    max: 100 // 总量，确保比例正确
                }
            ],
            yAxis: [
                {
                    type: 'category',
                    data: [''],
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        show: false
                    }
                }
            ],
            series: [
                {
                    name: 'Attainment',
                    type: 'bar',
                    stack: 'total',
                    barWidth: '40%',
                    itemStyle: {
                        borderRadius: [20, 0, 0, 20],
                        // 更加偏灰的蓝色系，降低饱和度，避免荧光感
                        color: new echarts.graphic.LinearGradient(
                            0, 0, 0, 1,
                            [
                                { offset: 0, color: '#6dd5fa' }, // 顶部高光
                                { offset: 0.6, color: '#1890ff' },
                                { offset: 1, color: '#005aa7' }  // 底部偏灰深蓝
                            ]
                        ),
                        shadowColor: 'rgba(0, 0, 0, 0.16)',
                        shadowBlur: 4,
                        shadowOffsetY: 3
                    },
                    label: {
                        show: true,
                        position: 'inside',
                        formatter: '{c}%',
                        color: '#333',
                        fontSize: 12
                    },
                    data: [data[0].attainment],
                    emphasis: {
                        itemStyle: {
                            opacity: 0.8
                        }
                    }
                },
                {
                    name: 'Quota',
                    type: 'bar',
                    stack: 'total',
                    barWidth: '40%',
                    itemStyle: {
                        borderRadius: [0, 20, 20, 0],
                        // 偏灰的绿色系，同样降低饱和度
                        color: new echarts.graphic.LinearGradient(
                            0, 0, 0, 1,
                            [
                                { offset: 0, color: '#bdfff3' }, // 顶部高光
                                { offset: 0.7, color: '#2ebf85' },
                                { offset: 1, color: '#11998e' }  // 底部偏灰深绿
                            ]
                        ),
                        shadowColor: 'rgba(0, 0, 0, 0.16)',
                        shadowBlur: 4,
                        shadowOffsetY: 3
                    },
                    label: {
                        show: true,
                        position: 'inside',
                        formatter: '{c}%',
                        color: '#333',
                        fontSize: 12
                    },
                    data: [data[0].quota],
                    emphasis: {
                        itemStyle: {
                            opacity: 0.8
                        }
                    }
                }
            ]
        };
    }
}
