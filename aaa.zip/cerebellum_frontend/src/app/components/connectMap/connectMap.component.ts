import { Component, computed, model, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzFlexModule } from 'ng-zorro-antd/flex';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { NgxGraphModule } from '@swimlane/ngx-graph';
import { NzMessageService } from 'ng-zorro-antd/message';
import { MapService, OnboardService } from 'src/app/service';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { InfraPopupManagementComponent } from './infra/infraPopupManagement.component';

interface Target {
  x: number;
  y: number;
}

interface MapAGLStatus {
  primary: string;
  secondary: string;
  pc1: boolean;
  s3b: boolean;
}

interface MapLoadblanceStatus {
  name: string;
  url: string;
}

interface MapRedisStauts {
  primary: string;
  secondary: string;
  pc1: boolean;
  s3b: boolean;
}

interface MapNodeStatus {
  layer7: boolean;
  loadblance: MapLoadblanceStatus;
  node2: boolean;
  kob_pc1: boolean;
  kob_s3b: boolean;
  redis: MapRedisStauts;
  agl: MapAGLStatus;
  vault: boolean;
}

@Component({
  selector: 'app-connection-map',
  imports: [
    CommonModule,
    NzTabsModule,
    NzFlexModule,
    NzGridModule,
    NzIconModule,
    NzTooltipModule,
    NgxGraphModule,
    NzButtonModule,
    NzPopoverModule,
    NzModalModule,
    InfraPopupManagementComponent
  ],
  providers: [MapService, OnboardService],
  standalone: true,
  templateUrl: './connectMap.component.html',
  styleUrl: './connectMap.component.scss',
})
export class ConnectMapComponent implements OnInit {
  protected width = window.innerWidth - 200;
  private readonly targets: Record<string, Target> = {
    agl: { x: 639, y: 320 },
    splunk: { x: 639, y: 95 },
    redis: { x: 639, y: 180 },
    vault: { x: 639, y: 420 },
  };
  protected currentTarget = signal<string>('agl');
  protected readonly targetTools = computed(() => {
    const target = this.targets[this.currentTarget()];
    return target;
  });
  protected aglStatus = {
    primary: "CMAPWPC1DB02.aus.amer.dell.com",
    secondary: "CMAPWS3BDB02.aus.amer.dell.com",
    pc1: true,
    s3b: true
  };
  protected redisStatus = {
    primary: "redis-11736.eredispaas09-pc1.amer.dell.com",
    secondary: "redis-11736.eredispaas09-s3b.amer.dell.com",
    pc1: true,
    s3b: true,
  };
  protected loadblance1 = "https://ai-validated-dispatch.dell.com";
  protected loadblance2 = "https://aivd-prod-02.kob.dell.com";
  protected redisPC1 = "redis-11736.eredispaas09-pc1.amer.dell.com";
  protected redisS3B = "redis-11736.eredispaas09-s3b.amer.dell.com";
  protected aglPC1 = "CMAPWPC1DB02.aus.amer.dell.com";
  protected aglS3B = "CMAPWS3BDB02.aus.amer.dell.com";
  kobName: string = '';
  NodeStatus: any;
  Layer7Status: boolean = true;
  loadblanceStatus: any = {
    name: "loadblance",
    url: "https://ai-validated-dispatch.dell.com",
    status: true
  };
  kobPC1Status: boolean = true;
  kobS3BStatus: boolean = true;
  vaultStatus: boolean = true;
  InfraInfoVisible =  model(false);
  PC1ErrorCount: number = 0;
  S3bErrorCount: number = 0;

  constructor(
    private message: NzMessageService,
    private mapService: MapService,
    private onboardService: OnboardService
  ) {}

  async ngOnInit() {
    await this.updateDataAsync();
    await this.getKobFailCountAsync();
  }

  async getKobFailCountAsync() {
    const pc1Payload = {
      cluster_name: "api-p1.kob.dell.com",
      service_name: "cmapc1kobprod01"
    };
    this.onboardService.getFailPodCount(pc1Payload).then((res: any) => {
      if(res.code == 200)
        this.PC1ErrorCount = res.data.failed_pods;
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    });
    const s3bPayload = {
      cluster_name: "api-s1.kob.dell.com",
      service_name: "cmas3bkobprod01"
    };
    this.onboardService.getFailPodCount(s3bPayload).then((res: any) => {
      if(res.code == 200)
        this.S3bErrorCount = res.data.failed_pods;
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    });
  }

  async updateDataAsync() {
    this.NodeStatus = await this.mapService.getStatusOfMap();
    if(this.NodeStatus.data) {
      this.Layer7Status = this.NodeStatus.data.layer7;
      this.loadblanceStatus = this.NodeStatus.data.loadblance;
      this.kobPC1Status = this.NodeStatus.data.kob_pc1;
      this.kobS3BStatus = this.NodeStatus.data.kob_s3b;
      this.redisStatus = this.NodeStatus.data.redis;
      this.aglStatus = this.NodeStatus.data.AGL;
      this.vaultStatus = this.NodeStatus.data.vault;
    }
  }

  onToolsClick(target: string) {
    this.currentTarget.set(target);
  }

  getKobLine(): { x: number; y: number } {
    return this.targetTools();
  }

  protected shouldShowAGL(): boolean {
    return this.currentTarget() === 'agl';
  }

  protected shouldShowRedis(): boolean {
    return this.currentTarget() === 'redis';
  }

  protected shouldShowSplunk(): boolean {
    return this.currentTarget() === 'splunk';
  }

  protected shouldShowVault(): boolean {
    return this.currentTarget() === 'vault';
  }

  plannedFailover() {
    this.mapService.changeNode(this.aglStatus.secondary)
    .then((res: any) => {
      this.message.success('success!');
      setTimeout(async () => {
        await this.updateDataAsync();
      }, 2000)
    })
    .catch((err: any) => this.message.error(err.message));
  }

  protected copy(text: string) {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        this.message.success('Copied successfully');
      })
      .catch((err) => {
        console.error('fail', err);
      });
  }

  protected getLinePath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return `M ${x1} ${y1} L ${x2} ${y2}`;
  }

  protected getCurvePath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;
    const controlX1 = midX;
    const controlY1 = y1;
    const controlX2 = midX;
    const controlY2 = y2;
    return `M ${x1} ${y1} C ${controlX1} ${controlY1}, ${controlX2} ${controlY2}, ${x2} ${y2}`;
  }

  // 生成偏移的曲线路径（用于粒子流，偏移量用于创建平行路径）
  protected getOffsetCurvePath(
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    offset: number
  ): string {
    // 计算垂直于线的方向
    const dx = x2 - x1;
    const dy = y2 - y1;
    const length = Math.sqrt(dx * dx + dy * dy);
    if (length === 0) return this.getCurvePath(x1, y1, x2, y2);

    // 垂直方向的单位向量
    const perpX = -dy / length;
    const perpY = dx / length;

    // 应用偏移
    const offsetX1 = x1 + perpX * offset;
    const offsetY1 = y1 + perpY * offset;
    const offsetX2 = x2 + perpX * offset;
    const offsetY2 = y2 + perpY * offset;

    return this.getCurvePath(offsetX1, offsetY1, offsetX2, offsetY2);
  }

  // 生成KOB到目标的路径（动态，使用曲线）
  protected getKobPath(x1: number, y1: number): string {
    const end = this.getKobLine();
    return this.getCurvePath(x1, y1, end.x, end.y);
  }

  protected getKobTextPostion(x1: number, y1: number): string {
    const end = this.getKobLine();
    const x2 = end.x;
    const y2 = end.y;
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;
    return `translate(${midX}, ${midY})`;
  }

  // 生成偏移的KOB路径（用于粒子流）
  protected getOffsetKobPath(x1: number, y1: number, offset: number): string {
    const end = this.getKobLine();
    return this.getOffsetCurvePath(x1, y1, end.x, end.y, offset);
  }

  // 生成Layer 7到Load Balancer的曲线路径
  protected getLayer7ToLoadBalancerPath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return this.getCurvePath(x1, y1, x2, y2);
  }

  // 生成Load Balancer到KOB的曲线路径
  protected getLoadBalancerToKobPath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return this.getCurvePath(x1, y1, x2, y2);
  }

  // 生成AGL到Node的曲线路径
  protected getAglToNodePath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return this.getCurvePath(x1, y1, x2, y2);
  }

  protected getRedisToRedisPath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return this.getCurvePath(x1, y1, x2, y2);
  }

  // 生成Node1到Node2的曲线路径
  protected getNodeToNodePath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return this.getCurvePath(x1, y1, x2, y2);
  }

  protected getLegendPath(
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string {
    return this.getCurvePath(x1, y1, x2, y2);
  }

  showModal(kobName: string) {
    this.kobName = kobName;
    this.InfraInfoVisible.set(true);
  }

  handleCancel() {
    this.InfraInfoVisible.set(false);
  }
}
