import { Component, input, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzCollapseModule } from 'ng-zorro-antd/collapse';
import { NzTableModule } from 'ng-zorro-antd/table';
import { OnboardService } from '../../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { InstanceInfoComponent } from '../../infraManagement/instanceInfo.component';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { DecommissionDialogComponent } from '../../infraManagement/decommissionDialog.component';
import { NzTreeModule } from 'ng-zorro-antd/tree';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { findAllKeysByTitle, getEnvFromKey, findNodeByKey, setAllExpanded, processTreeNodes, findFirstLeafNode } from 'src/app/util';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { AdjustDialogComponent } from '../../infraManagement/adjustDialog.component';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';
import { PodErrorStatus, PodStatusTooltip } from 'src/app/util/constant';

interface ButtonState {
  loading: boolean;
  disabled: boolean;
}

@Component({
  selector: 'app-popup-infraManagement',
  imports: [
    CommonModule,
    NzCollapseModule,
    NzTableModule,
    NzEmptyModule,
    NzSpinModule,
    NzButtonModule,
    NzIconModule,
    NzPopoverModule,
    NzTreeModule,
    NzGridModule,
    NzTooltipModule,
    NzPopconfirmModule,
    NzIconModule,
    InstanceInfoComponent,
    DecommissionDialogComponent,
    AdjustDialogComponent
  ],
  templateUrl: './infraPopupManagement.component.html',
  styleUrl: './infraPopupManagement.component.scss'
})

export class InfraPopupManagementComponent implements OnInit {

  @Input() serviceName: string = "cmapc1kobprod01";
  @Input() errorCount: number = 0;

  appID: string = ''
  appInfo: any = {}
  loading: boolean = false
  infoVisible: boolean = false
  decommissonVisible: boolean = false
  adjustVisible: boolean = false
  instanceInfo: any = {}
  tableData: any = []
  nodes: any = []
  expandedKeys: string[] = []
  selectedKeys: string[] = [];
  selectedInfo: any = {}
  tableLoading: boolean = false
  treeSpan: number = 5
  expandInfo: any
  pageSize: number = 10
  buttonStates: Record<number, ButtonState> = {};
  workloadInfo: any = {}
  currentScene: string = "KobName";
  payload: any = {
    env: "prod",
    service_name: this.serviceName,
    cluster_name: this.serviceName == "cmapc1kobprod01" ? "api-p1.kob.dell.com" : "api-s1.kob.dell.com",
    node_name: "KobName",
    app_id: "1005583"
  }
  treePayload: any = {
    env: "prod",
    service_name: this.serviceName,
    key: "node-0-2-1-0"
  }
  entityKeys: any = [];
  PodErrorStatus: any = PodErrorStatus
  PodStatusTooltip: any = PodStatusTooltip


  constructor(
    private onboardService: OnboardService,
    private message: NzMessageService,
  ) { }

  ngOnChanges(changes: any): void {
    // if (changes.info && changes.info.currentValue) {

    // }
    console.log(changes)
  }

  ngOnInit() {
    this.pageSize = window.innerWidth <= 1600 ? 5 : 10;
    this.queryTableList({
      env: "prod",
      service_name: this.serviceName,
      cluster_name: this.serviceName == "cmapc1kobprod01" ? "api-p1.kob.dell.com" : "api-s1.kob.dell.com",
      node_name: "KobName",
      app_id: "1005583"
    });
    this.getWorkloadTree({
      env: "prod",
      service_name: this.serviceName,
      key: "node-0-2-1-0"
    });
  }

  getWorkloadTree(data: any) {
    this.onboardService.getWorkloadTree(data).then((res: any) => {
      this.entityKeys = res.data;
    }).catch((error: any) => {
      this.message.error(error.message);
    });
  }

  queryTableList(data: any) {
    this.tableLoading = true
    this.onboardService.getInstanceTableList(data).then((res: any) => {
      if (this.currentScene == "KobName") {
        this.tableData = this.errorCount == 0 ? res.data : res.data.filter((t: any) => t.status == "Error" || t.status == "error");
      } else {
        this.tableData = this.errorCount == 0 ? res.data : res.data.filter((t: any) => PodErrorStatus.includes(t.status));
      }
      this.tableLoading = false
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
      this.tableLoading = false
    })
  }

  handleSelectPodTree(values: any) {
    const keys = this.entityKeys.filter((t: any) => t.title == values.name);
    this.currentScene = "Workload";
    this.queryTableList({
      env: "prod",
      node_name: "Workload",
      service_name: keys[0].title,
      cluster_name: keys[0].cluster_name || '',
      namespace_name: keys[0].namespace_name || ''
    })
  }

  handleAdjust(data: any) {
    this.adjustVisible = true
    this.workloadInfo = {
      ...data,
      title: this.serviceName,
      cluster_name: this.serviceName == "cmapc1kobprod01" ? "api-p1.kob.dell.com" : "api-s1.kob.dell.com",
    }
  }

  handleAdjustSuccess() {
    this.queryTableList({
      env: "prod",
      service_name: this.serviceName,
      node_name: "node-0-2-1-0",
    })
  }

  // POD Restart
  async handleRestart(item: any, index: number) {
    const state = this.getButtonState(index);

    // 开始 loading
    state.loading = true;
    state.disabled = true;
    this.onboardService.restartPod({
      cluster_name: this.serviceName == "cmapc1kobprod01" ? "api-p1.kob.dell.com" : "api-s1.kob.dell.com",
      service_name: this.serviceName,
      pod_name: item.name
    }).then((res: any) => {
      state.loading = false;
      state.disabled = true;
      this.queryTableList({
        env: "prod",
        service_name: this.serviceName,
        key: "node-0-2-1-0"
      })
      // disabled 5min
      setTimeout(() => {
        // 5秒后恢复可点击（前提是没被其他操作覆盖）
        if (this.buttonStates[index] === state) {
          state.disabled = false;
        }
      }, 5 * 60 * 1000);
      this.message.success('Restart successfully!');
    }).catch((error: any) => {
      state.loading = false;
      state.disabled = false;
      console.log(error)
      this.message.error(error.message);
    })
  }

  preScene() {
    this.currentScene = "KobName";
    this.queryTableList({
      env: "prod",
      service_name: this.serviceName,
      cluster_name: this.serviceName == "cmapc1kobprod01" ? "api-p1.kob.dell.com" : "api-s1.kob.dell.com",
      node_name: "KobName",
      app_id: "1005583"
    });
  }

  private getButtonState(index: number): ButtonState {
    if (!this.buttonStates[index]) {
      this.buttonStates[index] = { loading: false, disabled: false };
    }
    return this.buttonStates[index];
  }

  isButtonLoading(index: number): boolean {
    return this.getButtonState(index).loading;
  }

  isButtonDisabled(index: number): boolean {
    return this.getButtonState(index).disabled;
  }

  handleInfoVisibleChange(visible: boolean) {
    this.instanceInfo = {}
    this.infoVisible = visible
  }

  handleDecommissonVisibleChange(visible: boolean) {
    this.decommissonVisible = visible
  }

  handleAdjustVisibleChange(visible: boolean) {
    this.adjustVisible = visible
  }
}
