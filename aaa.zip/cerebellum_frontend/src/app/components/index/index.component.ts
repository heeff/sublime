import { Component, computed, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzFlexModule } from 'ng-zorro-antd/flex';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { Router } from '@angular/router';
import { NavigationService, IndexService } from 'src/app/service';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { NgxGraphModule } from '@swimlane/ngx-graph';
import { ConnectMapComponent } from '../connectMap/connectMap.component';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzMessageService } from 'ng-zorro-antd/message';
import { MetricsComponent } from '../benefitReporting/metrics.component';
import { Threshold } from 'src/app/util/constant';
import { BenefitReportingComponent } from '../benefitReporting/benefitReporting.component';


@Component({
  selector: 'app-index',
  imports: [
    CommonModule,
    NzTabsModule,
    NzFlexModule,
    NzGridModule,
    NzIconModule,
    NzTooltipModule,
    NgxGraphModule,
    NzButtonModule,
    NzPopoverModule,
    NzSpinModule,
    ConnectMapComponent,
    BenefitReportingComponent,
    MetricsComponent
  ],
  templateUrl: './index.component.html',
  styleUrl: './index.component.scss',
})
export class IndexComponent implements OnInit {

  infraInfo: any = {}
  _router: Router = this.router
  loading: boolean = false;
  threshold= Threshold
  vulnerabilityThreshold:number=0

  constructor(
    private router: Router,
    private navigationService: NavigationService,
    private indexService: IndexService,
    private message: NzMessageService,
  ) { }

  ngOnInit(): void {
    this.queryInfraInfo()
  }

  queryInfraInfo() {
    this.loading = true
    this.indexService.getInfraInfo().then((res: any) => {
      const data = res.data
      Object.keys(data).forEach(key => {
        if (typeof data[key] === 'number' && !isNaN(data[key])) {
          data[key] = parseFloat((data[key] * 100).toFixed(1));
        }
      });
      this.infraInfo = data
      this.loading = false
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
      this.loading = false
    })
  }

  // 跳转 envType 1:prod 2:nonprod
  navToJob(value: number, type?: string) {
    type &&
      this.navigationService.setNavigationData({
        type,
        value
      });
    this.router.navigate(['/sqlJobMonitor']);
  }

  navToVulnerability(type?:string){
    type &&
      this.navigationService.setNavigationData({
        type
      });
    this.router.navigate(['/vulnerabilityMgmt']);
  }

  navToReport(){
    this.router.navigate(['/reportMgmt']);
  }

  customLayout() {
    return (graph: any) => {
      // graph.nodes 是 ngx-graph 传入的节点数组
      const nodes = graph.nodes.map((node: any) => {
        // 如果节点已有 position，就直接用；否则给个默认值
        return {
          ...node,
          x: node.position?.x ?? 0,
          y: node.position?.y ?? 0,
          // 注意：ngx-graph 内部用 x/y，不是 position.x/position.y
        };
      });

      return {
        ...graph,
        nodes: nodes,
      };
    };
  }

}
