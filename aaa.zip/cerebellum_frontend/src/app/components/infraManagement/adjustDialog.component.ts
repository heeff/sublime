import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { AbstractControl, FormControl, FormGroup, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzInputModule } from 'ng-zorro-antd/input';
import { OnboardService } from 'src/app/service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { rangeValidator } from 'src/app/util';

@Component({
  selector: 'app-adjust-dialog',
  imports: [CommonModule, NzModalModule, ReactiveFormsModule, NzFormModule, NzButtonModule, NzSpinModule, NzInputModule],
  templateUrl: './adjustDialog.component.html',
  styleUrls: ['./adjustDialog.component.scss']
})
export class AdjustDialogComponent {
  @Input() visible: boolean = false;
  @Input() info: any = {};
  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() successEmit = new EventEmitter<boolean>();
  loading: boolean = true
  formGroup!: FormGroup;


  constructor(
    private onboardService: OnboardService,
    private message: NzMessageService
  ) {
    this.formGroup = new FormGroup({
      CPUAdjust: new FormControl('', [Validators.required]),
      MemoryAdjust: new FormControl('', Validators.required),
      PODAdjust: new FormControl('', Validators.required),
    });
  };

  ngOnChanges(changes: any): void {
    if (changes.visible && changes.visible.currentValue) {
      this.queryKobAvailableResource()
    }
  }

  queryKobAvailableResource() {
    this.onboardService.getKobAvailableResource({
      cluster_name: this.info.cluster_name,
      service_name: this.info.title,
    }).then((res: any) => {
      this.info = {
        ...this.info,
        requests_cpu: parseFloat(this.info.requests_cpu),
        requests_memory: parseFloat(this.info.requests_memory),
        ...res.data
      }
      this.formGroup.get('CPUAdjust')?.setValidators([Validators.required, rangeValidator(this.info.requests_cpu, this.info.available_cpu)]);
      this.formGroup.get('CPUAdjust')?.updateValueAndValidity();
      this.formGroup.get('MemoryAdjust')?.setValidators([Validators.required, rangeValidator(this.info.requests_memory, this.info.available_memory)]);
      this.formGroup.get('MemoryAdjust')?.updateValueAndValidity();
      this.formGroup.get('PODAdjust')?.setValidators([Validators.required, rangeValidator(this.info.pods, this.info.available_pods)]);
      this.formGroup.get('PODAdjust')?.updateValueAndValidity();
      this.loading = false
    }).catch((error: any) => {
      this.message.error(error.error.message);
    })
  }

  handleFormSubmit() {
    if (this.formGroup.valid) {
      this.onboardService.adjustWorkload({
        cluster_name: this.info.cluster_name,
        service_name: this.info.title,
        workload_name: this.info.name,
        cpu: this.formGroup.value.CPUAdjust.toString(),
        memory: this.formGroup.value.MemoryAdjust.toString(),
        pod_num: this.formGroup.value.PODAdjust,
      }).then((res: any) => {
        console.log(res)
        this.message.success(res.message);
        this.successEmit.emit(true);
        this.handleCancel();
      }).catch((error: any) => {
        this.message.error(error.error.message);
      })
    } else {
      Object.values(this.formGroup.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }

  handleCancel(): void {
    this.loading = true
    this.formGroup.reset()
    Object.keys(this.formGroup.controls).forEach(key => {
      this.formGroup.get(key)?.setErrors(null);
    });
    this.formGroup.setErrors({ 'invalid': true })
    this.visibleChange.emit(false);
  }

}