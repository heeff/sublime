import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzCollapseModule } from 'ng-zorro-antd/collapse';
import { NzTableModule } from 'ng-zorro-antd/table';
import { Subscription } from 'rxjs';
import { GlobalService, NavigationService, OnboardService } from '../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { InstanceInfoComponent } from './instanceInfo.component';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { DecommissionDialogComponent } from './decommissionDialog.component';
import { NzFormatEmitEvent, NzTreeModule } from 'ng-zorro-antd/tree';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { UTCToLocalPipe } from '../../helper/utcto-local.pipe';
import { findAllKeysByTitle, getEnvFromKey, findNodeByKey, setAllExpanded, processTreeNodes, findFirstLeafNode } from 'src/app/util';
import { TruncatePipe } from 'src/app/helper/truncate.pipe';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { AdjustDialogComponent } from './adjustDialog.component';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';
import { PodErrorStatus, PodStatusTooltip } from 'src/app/util/constant';

let selectID = ''
interface ButtonState {
  loading: boolean;
  disabled: boolean;
}

@Component({
  selector: 'app-infraManagement',
  imports: [
    CommonModule,
    NzCollapseModule,
    NzTableModule,
    NzEmptyModule,
    NzSpinModule,
    NzButtonModule,
    NzIconModule,
    NzPopoverModule,
    NzTreeModule,
    NzGridModule,
    UTCToLocalPipe,
    TruncatePipe,
    NzTooltipModule,
    NzPopconfirmModule,
    InstanceInfoComponent,
    DecommissionDialogComponent,
    AdjustDialogComponent
  ],
  templateUrl: './infraManagement.component.html',
  styleUrl: './infraManagement.component.scss'
})

export class InfraManagementComponent implements OnInit, OnDestroy {
  _globalSubscription!: Subscription;

  appID: string = ''
  appInfo: any = {}
  loading: boolean = false
  infoVisible: boolean = false
  decommissonVisible: boolean = false
  adjustVisible: boolean = false
  instanceInfo: any = {}
  tableData: any = []
  nodes: any = []
  expandedKeys: string[] = []
  selectedKeys: string[] = [];
  selectedInfo: any = {}
  tableLoading: boolean = false
  treeSpan: number = 5
  expandInfo: any
  pageSize: number = 10
  buttonStates: Record<number, ButtonState> = {};
  workloadInfo: any = {}
  PodErrorStatus: any = PodErrorStatus
  PodStatusTooltip: any = PodStatusTooltip


  constructor(private globalService: GlobalService,
    private onboardService: OnboardService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef,
    private navigationService: NavigationService
  ) { }

  ngOnDestroy() {
    this._globalSubscription.unsubscribe();
  }

  ngOnInit() {
    this.pageSize = window.innerWidth <= 1600 ? 5 : 10
    let appID = localStorage.getItem('appID');
    this.appID = appID || '';
    this.appID && this.queryList()
    this._globalSubscription = this.globalService.getMessage().subscribe(async e => {
      console.log(e)
      if (e.type == "appID") {
        this.appID = e.value
        this.appID && this.queryList()
      }
      if (e.type == "expandInfo") {
        this.expandInfo = e.value
        this.treeSpan = this.expandInfo.length === 2 ? 3 : 5
      }
    })

  }

  async queryList() {
    this.loading = true
    this.appInfo = {
      prod: {},
      nonProd: {}
    }
    this.onboardService.getInstanceList(this.appID).then((res: any) => {
      const data = res.data
      const keyAry = findAllKeysByTitle(data, 'KOB-NS-Service');
      this.nodes = processTreeNodes(data, {
        targetTitles: ['KOB-NS-Service'],
        targetKeys: keyAry
      })
      const navInfo = this.navigationService.consumeNavigationData();
      const firstNode = navInfo?.title ? findFirstLeafNode(this.nodes, {
        targetTitle: navInfo.title,
        targetEnv: navInfo.envType === 1 ? 'Prod' : 'Non-Prod'
      }) : findFirstLeafNode(this.nodes)
      if (firstNode?.key) {
        this.handleSelectKey(firstNode?.node, firstNode?.selectedKeys)
      }
      this.loading = false
      this.cdr.detectChanges();
      this.cdr.markForCheck();
    }).catch((error: any) => {
      console.log(error)
      this.loading = false
      this.message.error(error.error.message);
    })
  }

  handleInstanceInfo(id: any) {
    if (selectID === id && Object.keys(this.instanceInfo).length !== 0) {
      this.infoVisible = true
      return
    }
    selectID = id
    this.infoVisible = true
    this.onboardService.getInstanceInfo(id).then((res: any) => {
      let data = res.data || {}
      this.instanceInfo = data
      this.cdr.markForCheck();
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    })

  }

  onExpandChange(e: NzFormatEmitEvent): void {
    console.log(e)
    const node = e.node;
    if (node?.origin?.title === "Non-Prod" || node?.origin?.title === "Prod") {
      if (node?.isExpanded === false) {
        if (this.expandInfo === 0 || !this.expandInfo) {
          this.expandInfo = []
        }
        this.expandInfo.push({
          title: node?.origin?.title,
          isExpanded: node?.isExpanded
        })
        this.globalService.sendMessage(this.expandInfo, 'expandInfo')
      } else {
        const newExpandInfo = this.expandInfo.filter((item: any) => item.title !== node?.origin?.title)
        this.globalService.sendMessage(newExpandInfo, 'expandInfo')
      }
    }

    if (e.eventName === 'expand' && node?.parentNode?.origin?.title === 'KOB-NS-Service') {
      // 防止重复加载
      if (node.origin['loading'] || node.getChildren().length > 0) return;
      // 设置 loading 状态（可选）
      node.origin['loading'] = true;
      node.isLeaf = true
      this.onboardService.getWorkloadTree({
        env: getEnvFromKey(node.origin.key),
        service_name: node.origin.title,
        key: node.origin.key
      }).then((res: any) => {
        // 1. 递归设置所有新节点 expanded: true
        const processedChildren = setAllExpanded(res.data || []);

        // 2. 找到原始数据中的目标节点
        const targetNode = findNodeByKey(this.nodes, node.origin.key);
        if (targetNode) {
          targetNode.children = processedChildren; // 新数组引用
          // targetNode.expanded = true; // 确保自身已展开
        }
        // 3. 触发 nz-tree 重新渲染
        this.nodes = [...this.nodes];
        // this.nodes = processTreeNodes(this.nodes, {
        //   targetTypes: ['Workload'],
        // })
        this.cdr.markForCheck();
      }).catch((error: any) => {
        console.log(error)
        this.message.error(error.message);
      })
    }
  }

  queryTableList(data: any) {
    this.tableLoading = true
    this.onboardService.getInstanceTableList(data).then((res: any) => {
      this.tableData = res.data
      this.cdr.markForCheck();
      this.tableLoading = false
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
      this.tableLoading = false
    })
  }

  getPlayload(node: any) {

  }

  handleTreeClick(event: any) {
    console.log(event)
    this.selectedInfo = event.node
    const node = event.node;
    this.tableData = []
    const type = node?.origin?.type
    const data = {
      env: getEnvFromKey(node.origin.key),
      service_name: node.origin.title,
      node_name: type ? type : '',
      app_id: type === 'Workload' ? '' : this.appID,
      cluster_name: type === 'KobName' || type === 'Workload' ? node.origin.cluster_name : '',
      namespace_name: type === 'Workload' ? node.origin.namespace_name : ''
    }
    this.queryTableList(data)
  }

  handleSelectKey(nodes: any, keys: Array<string>) {
    this.selectedKeys = keys
    this.tableData = []
    console.log(nodes)
    this.queryTableList({
      env: getEnvFromKey(keys[0]),
      service_name: nodes.title,
      node_name: nodes['type'] ? nodes['type'] : '',
      app_id: nodes['type'] === 'Workload' ? '' : this.appID,
      cluster_name: nodes['type'] === 'KobName' || nodes['type'] === 'Workload' ? nodes['cluster_name'] : '',
      namespace_name: nodes['type'] === 'Workload' ? nodes['namespace_name'] : ''
    })
  }

  handleSelectPodTree(values: any) {
    const keyAry = findAllKeysByTitle(this.nodes, values.name);
    const nodes = findNodeByKey(this.nodes, keyAry[0]);
    this.selectedInfo = nodes
    this.handleSelectKey(nodes, [keyAry[0]])
  }

  handleAdjust(data: any) {
    this.adjustVisible = true
    this.workloadInfo = {
      ...data,
      ...this.selectedInfo?.origin
    }
  }

  handleAdjustSuccess() {
    console.log(this.workloadInfo)
    this.queryTableList({
      env: getEnvFromKey(this.workloadInfo.key),
      service_name: this.workloadInfo.title,
      node_name: this.workloadInfo?.type ? this.workloadInfo?.type : '',
      app_id: this.workloadInfo?.type === 'Workload' ? '' : this.appID,
      cluster_name: this.workloadInfo?.type === 'KobName' || this.workloadInfo?.type === 'Workload' ? this.workloadInfo.cluster_name : '',
      namespace_name: this.workloadInfo?.type === 'Workload' ? this.workloadInfo.namespace_name : ''
    })
  }

  // POD Restart
  async handleRestart(item: any, index: number) {
    const state = this.getButtonState(index);

    // 开始 loading
    state.loading = true;
    state.disabled = true;
    this.onboardService.restartPod({
      cluster_name: this.selectedInfo.parentNode.origin.cluster_name,
      service_name: this.selectedInfo.parentNode.origin.title,
      pod_name: item.name
    }).then((res: any) => {
      state.loading = false;
      state.disabled = true;
      this.queryTableList({
        env: getEnvFromKey(this.selectedInfo.origin.key),
        service_name: this.selectedInfo.origin.title,
        node_name: this.selectedInfo?.origin?.type ? this.selectedInfo?.origin?.type : '',
        app_id: this.selectedInfo?.origin?.type === 'Workload' ? '' : this.appID,
        cluster_name: this.selectedInfo?.origin?.type === 'KobName' || this.selectedInfo?.origin?.type === 'Workload' ? this.selectedInfo?.origin?.cluster_name : '',
        namespace_name: this.selectedInfo?.origin?.type === 'Workload' ? this.selectedInfo?.origin?.namespace_name : ''
      })
      // disabled 5min
      setTimeout(() => {
        // 5秒后恢复可点击（前提是没被其他操作覆盖）
        if (this.buttonStates[index] === state) {
          state.disabled = false;
        }
      }, 5 * 60 * 1000);
      this.message.success('Restart successfully!');
    }).catch((error: any) => {
      state.loading = false;
      state.disabled = false;
      console.log(error)
      this.message.error(error.message);
    })
  }

  private getButtonState(index: number): ButtonState {
    if (!this.buttonStates[index]) {
      this.buttonStates[index] = { loading: false, disabled: false };
    }
    return this.buttonStates[index];
  }

  isButtonLoading(index: number): boolean {
    return this.getButtonState(index).loading;
  }

  isButtonDisabled(index: number): boolean {
    return this.getButtonState(index).disabled;
  }

  handleInfoVisibleChange(visible: boolean) {
    this.instanceInfo = {}
    this.infoVisible = visible
  }

  handleDecommissonVisibleChange(visible: boolean) {
    this.decommissonVisible = visible
  }

  handleAdjustVisibleChange(visible: boolean) {
    this.adjustVisible = visible
  }
}
