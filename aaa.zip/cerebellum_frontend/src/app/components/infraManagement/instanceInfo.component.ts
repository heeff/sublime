import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { ReactiveFormsModule } from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzTableModule } from 'ng-zorro-antd/table';

@Component({
  selector: 'app-instanceInfo',
  standalone: true,
  imports: [CommonModule, NzModalModule, ReactiveFormsModule, NzFormModule, NzButtonModule, NzSpinModule, NzTableModule],
  templateUrl: './instanceInfo.component.html',
  styleUrls: ['./instanceInfo.component.scss']
})
export class InstanceInfoComponent {
  @Input() visible: boolean = false;
  @Input() info: any = {};
  @Output() visibleChange = new EventEmitter<boolean>();
  loading: boolean = true
  Object = Object;

  constructor() { }

  ngOnChanges(changes: any): void {
    if (changes.info && changes.info.currentValue) {
      Object.keys(changes.info.currentValue).length !== 0 && (this.loading = false)
      this.info = this.processObjectKeys(changes.info.currentValue)
      console.log(this.info)
    }
  }

  processObjectKeys(obj: any) {
    // 如果不是对象或为null，直接返回
    if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) {
      return obj;
    }

    const processed: any = {};
    // 遍历对象所有key
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (key !== 'list') {
          // 处理当前key
          const newKey = this.formatKey(key);
          // 递归处理值（如果值是对象）
          processed[newKey] = this.processObjectKeys(obj[key]);
        } else {
          processed[key] = obj[key]
        }
      }
    }
    return processed;
  }

  // 获取对象的所有key（用于模板中遍历）
  getKeys(obj: any): string[] {
    return obj ? Object.keys(obj) : [];
  }

  // 格式化key显示（处理下划线和驼峰命名）
  formatKey(key: string) {
    return key.split('_')
      .map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
      .join(' ')
      .trim();
  }


  handleCancel(): void {
    this.loading = true
    this.visibleChange.emit(false);
  }

}