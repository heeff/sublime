import { Component, OnInit, ChangeDetectorRef, inject, input, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { HealthService, OnboardService } from '../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { JobRunOptions, JobStatusOptions } from 'src/app/util/constant';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';

@Component({
  selector: 'app-RTDJobManagement',
  templateUrl: './RTDJobManagement.component.html',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzGridModule,
    NzFormModule,
    FormsModule,
    NzTableModule,
    NzPaginationModule,
    NzInputModule,
    NzIconModule,
    NzButtonModule,
    NzSelectModule
  ],
})
export class RTDJobManagementComponent implements OnInit {
  @Input() info: any = {};

  private fb = inject(NonNullableFormBuilder);
  validateForm = this.fb.group({
    status: this.fb.control<string[]>([]),
    job_name: this.fb.control([]),
    job_run: this.fb.control('Last run'),
  });
  categoryName = 'Kafka'
  tableData: any = {
    list: [],
    pageNum: 1,
    pageSize: 20,
    total: 100
  };
  loading: boolean = false
  statusOptions: any = JobStatusOptions
  jobNameOptions: any = []
  jobRunOptions: any = JobRunOptions


  constructor(private healthService: HealthService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
  }

  ngOnChanges(changes: any): void {
    if (changes.info && changes.info.currentValue) {
      const info = changes.info.currentValue
      if (info.value < 100) {
        this.validateForm.get('status')?.setValue(['Failed'])
      }
      this.querySQLJobNameList()
    }
  }

  async querySQLJobNameList() {
    this.healthService.getSQLJobNameOptionsList({
      category_name: this.categoryName
    }).then((res: any) => {
      this.jobNameOptions = res.data
      this.queryList()
    }).catch((error: any) => {
      this.message.error(error.message);
      this.loading = false
    })
  }

  async queryList() {
    this.loading = true
    this.healthService.getSQLJobList({
      page_size: this.tableData.pageSize,
      page_num: this.tableData.pageNum,
      category_name: this.categoryName,
      ...this.validateForm.value
    }).then((res: any) => {
      this.tableData.list = res.data.data || []
      this.tableData.total = res.data.total_count
      this.cdr.markForCheck();
      this.loading = false
    }).catch((error: any) => {
      this.message.error(error.message);
      this.loading = false
    })
  }

  handleSearch() {
    this.tableData.pageNum = 1
    this.queryList()
  }

  handlePageIndexChange(page: number) {
    this.tableData.pageNum = page
    this.queryList()
  }

  handleReset() {
    this.validateForm.reset()
    this.tableData.pageNum = 1
    this.queryList()
  }
}