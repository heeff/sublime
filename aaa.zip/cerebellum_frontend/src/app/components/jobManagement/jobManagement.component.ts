import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NavigationService } from '../../service';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { RTDJobManagementComponent } from './RTDJobManagement.component';
import { HybridJobManagementComponent } from './hybridJobManagement.component';
import { AIVDJobManagementComponent } from './AIVDJobManagement.component';

@Component({
  selector: 'app-job-management',
  templateUrl: './jobManagement.component.html',
  styleUrls: ['./jobManagement.component.scss'],
  imports: [
    CommonModule,
    NzGridModule,
    NzTableModule,
    NzIconModule,
    NzButtonModule,
    NzTabsModule,
    RTDJobManagementComponent,
    HybridJobManagementComponent,
    AIVDJobManagementComponent,
  ],
})
export class JobManagementComponent implements OnInit {
  selectedIndex = 0;
  info: any = {};

  constructor(
    private navigationService: NavigationService,
  ) { }

  ngOnInit() {
    const navInfo = this.navigationService.consumeNavigationData();
    if (navInfo?.type) {
      this.info = navInfo;
      switch (navInfo.type) {
        case 'RTD':
          this.selectedIndex = 0;
          break;
        case 'Hybrid':
          this.selectedIndex = 1;
          break;
        case 'AIVD':
          this.selectedIndex = 2;
          break;
        default:
          break;
      }
    }
  }

}