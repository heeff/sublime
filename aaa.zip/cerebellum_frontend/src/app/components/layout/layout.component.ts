import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { filter, takeUntil } from 'rxjs/operators';
import { BreadcrumbComponent, BreadcrumbItem } from '../breadcrumb/breadcrumb.component';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { MenuComponent, MenuItem } from '../menu/menu.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { Subject, Subscription } from 'rxjs';
import { GlobalService, StorageService, UserService } from 'src/app/service';
import { AdminRoutes, menuItems } from 'src/app/util/constant';
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, MenuComponent, NzSpinModule, NzCardModule, NzIconModule],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent implements OnInit {
  private destroy$ = new Subject<void>();

  currentUrl: string = '';
  isCollapsed = true;
  username = 'Yina_H';
  hasPermission = true;
  loading = false
  token: string = '1'

  // 面包屑数据
  breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Home', url: '/', active: true }
  ];

  constructor(private router: Router,
    private globalService: GlobalService,
    private message: NzMessageService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    const initUrl = this.router.url;
    this.currentUrl = initUrl;
    const isManagementInit = AdminRoutes.includes(initUrl);
    this.globalService.sendMessage(isManagementInit, 'isManagement');

    // 监听路由变化，更新面包屑
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd), takeUntil(this.destroy$)
    ).subscribe((event: NavigationEnd) => {
      const url = event.urlAfterRedirects || event.url;
      const isManagement = AdminRoutes.includes(url);
      this.globalService.sendMessage(isManagement, 'isManagement');
      // 更新当前 URL（可用于面包屑等）
      this.currentUrl = url;
      // 如果需要更新面包屑，可在此调用
      // this.updateBreadcrumb(url);
    });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  queryEPI() {
    this.userService.getEPIList().then((res: any) => {
      this.globalService.sendMessage(res.data, 'epiList')
    }).catch((error: any) => {
      this.message.error(error.error.message);
    })
  }

  onMenuCollapseChange(collapsed: boolean): void {
    this.isCollapsed = collapsed;
  }

  /**
   * 根据当前路由更新面包屑导航
   */
  // private updateBreadcrumb(url: string): void {
  //   const breadcrumbMap: { [key: string]: BreadcrumbItem[] } = {
  //     '/': [
  //       { label: 'Home', url: '/', active: true }
  //     ],
  //     '/onboard': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Management', url: '/onboard', active: true }
  //     ],
  //     '/permission': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Permission', url: '/permission', active: true }
  //     ],
  //     '/dashboard': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Dashboard', url: '/dashboard', active: true }
  //     ],
  //     '/users': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Users', url: '/users', active: true }
  //     ],
  //     '/infraManagement': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Infra Management', url: '/infraManagement', active: true }
  //     ],
  //     '/apiManagement': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'api Management', url: '/apiManagement', active: true }
  //     ],
  //     '/projects': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Projects', url: '/projects', active: true }
  //     ],
  //     '/settings': [
  //       { label: 'Home', url: '/', active: false },
  //       { label: 'Settings', url: '/settings', active: true }
  //     ]
  //   };

  //   this.breadcrumbItems = breadcrumbMap[url] || [
  //     { label: 'Home', url: '/', active: false },
  //     { label: 'Page', url: url, active: true }
  //   ];
  // }
}
