import { Component, EventEmitter, Output, inject, Input, input, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { GlobalService, OnboardService, PermissionService, StorageService, UserService } from 'src/app/service';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { filterApplication } from 'src/app/util';
import { RoleList } from 'src/app/util/constant';
import { debounceTime, Subscription } from 'rxjs';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { EpiUserModel } from 'src/app/service/user/user.model';

@Component({
    selector: 'app-addPermission-dialog',
    standalone: true,
    imports: [
        CommonModule,
        NzModalModule,
        ReactiveFormsModule,
        NzFormModule,
        NzInputModule,
        NzButtonModule,
        NzSelectModule,
        NzAutocompleteModule,
        NzSpinModule
    ],
    templateUrl: './addPermission.component.html',
    styleUrls: ['./addPermission.component.scss']
})
export class AddPermissionDialogComponent {
    _globalSubscription!: Subscription;
    dataSub!: Subscription;
    valueChangeSub!: Subscription; // 表单值变化订阅

    @Input() visible: boolean = false;
    @Output() visibleChange = new EventEmitter<boolean>();
    @Output() submitEvent = new EventEmitter<any>();

    private fb = inject(NonNullableFormBuilder);
    validateForm = this.fb.group({
        Badge: this.fb.control('', [Validators.required]),
        ApplicationID: this.fb.control('', [Validators.required]),
        Role: this.fb.control('', [Validators.required]),
    });

    isLoading: boolean = false
    appInfo: any = {}
    filterOption: any = filterApplication
    applicationList: any[] = []
    roleList: any = RoleList
    epiList: EpiUserModel[] = []; // 缓存所有接口数据
    filteredOptions: EpiUserModel[] = []; // 过滤后的结果
    selectOptions: any = {};



    constructor(private storageService: StorageService,
        private message: NzMessageService,
        private userService: UserService,
        private permissionService: PermissionService,
        private cdr: ChangeDetectorRef
    ) { }

    // 清理资源
    ngOnDestroy(): void {
        // this.dataSub.unsubscribe();
        // this.valueChangeSub.unsubscribe();
    }

    ngOnInit(): void {
        // 初始化时加载所有数据（只加载一次）
        this.dataSub = this.userService.getEPIList().then((res: any) => {
            // this.globalService.sendMessage(res.data, 'epiList')
            this.epiList = res.data
        }).catch((error: any) => {
            this.message.error(error.error.message);
        })

        this.valueChangeSub = this.validateForm.get('Badge')!.valueChanges
            .pipe(
                // 防抖：输入停止300ms后执行（避免频繁过滤）
                debounceTime(300)
            )
            .subscribe((value) => {
                this.filterOptions(value); // 触发过滤逻辑
            });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['visible'] && changes['visible'].currentValue) {
            this.applicationList = JSON.parse(this.storageService.getData('applicationList'))
        }
    }

    queryEPI() {
        this.userService.getEPIList().then((res: any) => {
            this.epiList = res.data
            this.filteredOptions = this.epiList;
        }).catch((error: any) => {
            this.message.error(error.error.message);
        })
    }

    // 本地过滤逻辑
    private filterOptions(keyword: string): void {
        const trimmedKeyword = keyword.trim().toLowerCase();
        if (trimmedKeyword === '') {
            this.filteredOptions = [];
            return;
        }
        setTimeout(() => {
            this.filteredOptions = this.epiList.filter((option: EpiUserModel) =>
                option.User_NT.toLowerCase().includes(trimmedKeyword)
            );
        }, 0);
    }

    // 选中建议项时触发（自动填充到表单）
    handleSelect(option: any): void {
        // 将选中项的值同步到表单控件
        // this.validateForm.get('NT')!.setValue(option.nzLabel);
        this.selectOptions = {
            user_badge: option.nzValue,
            user_nt: option.nzLabel,
        }
    }

    handleSubmit() {
        this.isLoading = true
        this.permissionService.addPermission({
            app_role_id: this.validateForm.get('Role')?.value,
            user_badge: this.validateForm.get('Badge')?.value,
            user_nt: this.selectOptions.user_nt,
            app_id: this.validateForm.get('ApplicationID')?.value
        }).then((res: any) => {
            setTimeout(() => {
                this.handleCancel()
                this.submitEvent.emit()
                this.isLoading = false
                // 强制触发变更检测
                this.cdr.markForCheck();
            }, 0);
            this.message.success('Added successfully')
        }).catch((error: any) => {
            this.message.error(error.message);
            setTimeout(() => {
                this.isLoading = false;
                this.cdr.markForCheck();
            }, 0);
        })
    }


    handleCancel(): void {
        this.validateForm.reset();
        this.isLoading = false;
        setTimeout(() => {
            this.visible = false;
            this.visibleChange.emit(false);
        }, 0);
    }
}