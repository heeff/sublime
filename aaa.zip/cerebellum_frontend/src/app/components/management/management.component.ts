import { Component, OnInit,ChangeDetectorRef  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { OnboardDialogComponent } from './onboardDialog.component';
import { OnboardService } from '../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';

@Component({
  selector: 'app-management',
  templateUrl: './management.component.html',
  styleUrl: './management.component.scss',
  imports: [CommonModule, FormsModule, NzTableModule, NzSelectModule, NzIconModule, NzButtonModule, NzModalModule, OnboardDialogComponent, NzPopconfirmModule],
})
export class ManagementComponent implements OnInit {
  addVisible: boolean = false
  tableData: any = {
    list: [],
    pageNum: 1,
    pageSize: 20,
    total: 0
  };
  loading: boolean = false
  applicationList: any[] = []
  selectedValue = null;


  constructor(private onboardService: OnboardService,
    private modal: NzModalService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef 
  ) { }

  ngOnInit() {
    this.queryList()
  }

  async queryList() {
    this.loading = true
    this.onboardService.getOnboardList().then((res: any) => {
      this.tableData.list = res.data || []
      this.cdr.markForCheck();
      this.loading = false
    }).catch((error: any) => {
      this.message.error(error.message);
      this.loading = false
    })
  }

  handleApplicationIDAdd(): void {
    this.handleAddVisibleChange()
  }

  handleApplicationIDDelete(id: any): void {
    this.onboardService.deleteOnboardAPP({ app_id:id }).then((res: any) => {
      this.message.success('Successfully deleted')
      this.queryList()
    }).catch((error: any) => {
      this.message.error(error.message);
    })
  }

  handleAddVisibleChange(){
    this.addVisible = !this.addVisible
  }

}