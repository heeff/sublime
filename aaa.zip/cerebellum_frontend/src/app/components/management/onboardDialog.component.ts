import { Component, EventEmitter, Output, inject, Input, input, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { OnboardService } from 'src/app/service';

@Component({
  selector: 'app-onboard-dialog',
  standalone: true,
  imports: [CommonModule, NzModalModule, ReactiveFormsModule, NzFormModule, NzInputModule, NzAlertModule, NzButtonModule],
  templateUrl: './onboardDialog.component.html',
  styleUrl: './onboardDialog.component.scss'
})
export class OnboardDialogComponent {
  @Input() visible: boolean = false;
  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() submitEvent = new EventEmitter<any>();

  private fb = inject(NonNullableFormBuilder);
  validateForm = this.fb.group({
    ApplicationID: this.fb.control('', [Validators.required]),
  });

  isLoading: boolean = false
  isSearch: boolean = false
  appInfo: any = {}

  constructor(private onboardService: OnboardService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
  }


  handleSearch() {
    this.isLoading = true;
    const id = this.validateForm.get('ApplicationID')?.value as string;

    this.onboardService.searchApplicationID(id).then((res: any) => {
      // 使用 setTimeout 避免在变更检测期间修改值
      setTimeout(() => {
        this.appInfo = res.data;
        this.isSearch = true;
        this.isLoading = false;
        // 强制触发变更检测
        this.cdr.markForCheck();
      }, 0);
    }).catch((error: any) => {
      this.message.error(error.error.message);
      setTimeout(() => {
        this.isLoading = false;
        this.cdr.markForCheck();
      }, 0);
    });
  }

  async handleSubmit() {
    if (this.validateForm.valid) {
      this.isSearch ? this.handleOk() : this.handleSearch()
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }

  handleOk() {
    this.isLoading = true
    const id = this.validateForm.get('ApplicationID')?.value as string;
    this.onboardService.onboardApplicationAdd({ app_id: id }).then((res: any) => {
      setTimeout(() => {
        this.handleCancel()
        this.submitEvent.emit()
        this.isLoading = false
        // 强制触发变更检测
        this.cdr.markForCheck();
      }, 0);
      this.message.success('Added successfully')
    }).catch((error: any) => {
      this.message.error(error.message);
      setTimeout(() => {
        this.isLoading = false;
        this.cdr.markForCheck();
      }, 0);
    })
  }

  handleCancel(): void {
    this.validateForm.reset();
    this.isSearch = false;
    this.isLoading = false;
    setTimeout(() => {
      this.visible = false;
      this.visibleChange.emit(false);
    }, 0);
  }
}