import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { AddPermissionDialogComponent } from './addPermission.component';
import { PermissionService } from 'src/app/service';
import { UpdatePermissionDialogComponent } from './updatePermission.component';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';

@Component({
    selector: 'app-permission',
    templateUrl: './permission.component.html',
    styleUrls: ['./permission.component.scss'],
    imports: [NzTableModule, NzIconModule, NzSpinModule, NzButtonModule, AddPermissionDialogComponent, UpdatePermissionDialogComponent, NzPopconfirmModule],
})
export class PermissionComponent implements OnInit {
    expandSet = new Set<number>();
    addVisible: boolean = false
    updateVisible: boolean = false
    tableData: any = {
        list: [],
        pageNum: 1,
        pageSize: 20,
        total: 0
    };
    loading: boolean = false
    selectInfo: any = {}

    constructor(private message: NzMessageService,
        private permissionService: PermissionService,
        private cdr: ChangeDetectorRef
    ) { }

    ngOnInit() {
        this.queryList()
    }

    async queryList() {
        this.loading = true
        this.permissionService.getPermissionList().then((res: any) => {
            const data = res.data || []
            data.forEach((item: any) => {
                item.User_List.forEach((child: any) => {
                    if (child.App_Role_Id === 1) {
                        child.App_Role_Name = 'RO'
                    } else if (child.App_Role_Id === 2) {
                        child.App_Role_Name = 'RW'
                    } else if (child.App_Role_Id === 9999) {
                        child.App_Role_Name = 'Admin'
                    }
                })
            })
            this.tableData.list = data
            this.cdr.markForCheck();
            this.loading = false
        }).catch((error: any) => {
            this.message.error(error.message);
            this.loading = false
        })
    }

    onExpandChange(App_Number: number, checked: boolean): void {
        if (checked) {
            this.expandSet.add(App_Number);
        } else {
            this.expandSet.delete(App_Number);
        }
    }

    handlePermissionAdd() {

    }

    handleUpdatePermissin(userInfo: any, appInfo: any) {
        this.selectInfo = {
            ...appInfo,
            ...userInfo
        }
        this.handleUpdateVisibleChange()
    }

    handlePermissinDelete(userInfo: any, appInfo: any) {
        this.permissionService.deletePermission({
            user_nt: userInfo.User_NT,
            app_id: appInfo.App_Number.toString()
        }).then((res: any) => {
            this.message.success('Successfully deleted')
            this.queryList()
        }).catch((error: any) => {
            this.message.error(error.message);
        })
    }

    handleAddVisibleChange() {
        this.addVisible = !this.addVisible
    }

    handleUpdateVisibleChange() {
        this.updateVisible = !this.updateVisible
    }
}