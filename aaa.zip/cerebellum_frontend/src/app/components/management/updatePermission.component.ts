import { Component, EventEmitter, Output, inject, Input, input, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { RoleList } from 'src/app/util/constant';
import { PermissionService } from 'src/app/service';

@Component({
    selector: 'app-updatePermission-dialog',
    standalone: true,
    imports: [CommonModule, NzModalModule, ReactiveFormsModule, NzFormModule, NzButtonModule, NzSelectModule],
    templateUrl: './updatePermission.component.html',
})

export class UpdatePermissionDialogComponent {
    @Input() visible: boolean = false;
    @Input() info: any = {};
    @Output() visibleChange = new EventEmitter<boolean>();
    @Output() submitEvent = new EventEmitter<any>();

    private fb = inject(NonNullableFormBuilder);
    validateForm = this.fb.group({
        Role: this.fb.control('', [Validators.required]),
    });
    isLoading: boolean = false
    roleList: any = RoleList

    constructor(
        private message: NzMessageService,
        private cdr: ChangeDetectorRef,
        private permissionService: PermissionService
    ) { }

    ngOnInit(): void {
    }

    ngOnChanges(changes: any): void {
        // if (changes.info && changes.info.currentValue) {
        //     this.validateForm.patchValue({
        //     Role: changes.info.currentValue.App_Role_Id
        //   })
        // }
    }


    handleSelectChange(value: any) {

    }
    handleSubmit() {
        this.isLoading = true
        this.permissionService.updatePermission({ 
            app_role_id: this.validateForm.get('Role')?.value,
            user_nt: this.info.User_NT,
            app_id: this.info.App_Number.toString()
        }).then((res: any) => {
            setTimeout(() => {
                this.handleCancel()
                this.submitEvent.emit()
                this.isLoading = false
                // 强制触发变更检测
                this.cdr.markForCheck();
            }, 0);
            this.message.success('Modified successfully')
        }).catch((error: any) => {
            this.message.error(error.message);
            setTimeout(() => {
                this.isLoading = false;
                this.cdr.markForCheck();
            }, 0);
        })
    }

    handleCancel(): void {
        this.validateForm.reset();
        this.isLoading = false;
        setTimeout(() => {
            this.visible = false;
            this.visibleChange.emit(false);
        }, 0);
    }
}