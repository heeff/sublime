import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { GlobalService, StorageService } from 'src/app/service';
import { Subscription } from 'rxjs';
import { menuItems, AdminRoutes } from 'src/app/util/constant';

export interface MenuItem {
  key: string;
  icon: string;
  label: string;
  route?: string;
  isAdmin: boolean;
  children?: { key: string; label: string; route?: string }[];
}

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    NzMenuModule,
    NzIconModule,
    NzLayoutModule
  ],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.scss'
})
export class MenuComponent implements OnInit {
  _globalSubscription!: Subscription;

  @Input() isCollapsed: boolean = true;
  @Output() menuCollapseChange = new EventEmitter<boolean>();

  menuList: MenuItem[] = [];

  constructor(
    private globalService: GlobalService,
    private router: Router
  ) { }

  ngOnDestroy() {
    this._globalSubscription.unsubscribe();
  }

  ngOnInit(): void {
    // 初始化时主动检查当前 URL，设置菜单的初始值（不依赖消息）
    const currentUrl = this.router.url;
    const isManagement = AdminRoutes.includes(currentUrl);
    this.updateMenuList(isManagement);
    
    // 订阅后续的路由变化消息
    this._globalSubscription = this.globalService.getMessage().subscribe(async e => {
      if (e.type === "isManagement") {
        this.updateMenuList(e.value)
      }
    })
  }

  private updateMenuList(isManagement: boolean): void {
    let ary: MenuItem[] = []
    menuItems.map(item => {
      if (item.isAdmin === isManagement) {
        ary.push(item)
      }
    })
    this.menuList = ary.length > 0 ? ary : menuItems.filter(item => !item.isAdmin)
  }

  get sidebarWidth(): string {
    return this.isCollapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)';
  }

  onMenuCollapse(): void {
    this.menuCollapseChange.emit(!this.isCollapsed);
  }

  onMenuHover(): void {
    if (this.isCollapsed) {
      this.menuCollapseChange.emit(false);
    }
  }

  onMenuLeave(): void {
    if (!this.isCollapsed) {
      this.menuCollapseChange.emit(true);
    }
  }

  onMenuItemClick(item: any): void {
    // 菜单项点击处理
  }
}
