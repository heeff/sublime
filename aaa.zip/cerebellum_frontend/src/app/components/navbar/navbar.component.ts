import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { GlobalService, OnboardService, StorageService } from '../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Subscription } from 'rxjs';
import { filterApplication } from 'src/app/util';
import { AdminRoutes } from 'src/app/util/constant';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    NzDropDownModule,
    NzMenuModule,
    NzIconModule,
    NzSelectModule
  ],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent implements OnInit {
  _globalSubscription!: Subscription;

  applicationList: any[] = []
  selectedValue: any = null;
  currentUrl: string = '';
  isManagement: boolean = false;
  filterOption: any = filterApplication
  userInfo: any = {}

  constructor(private onboardService: OnboardService,
    private globalService: GlobalService,
    private storageService: StorageService,
    private message: NzMessageService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
  }

  ngOnDestroy() {
    this._globalSubscription.unsubscribe();
  }

  ngOnInit(): void {
    // 初始化时主动检查当前 URL，设置 isManagement 的初始值（不依赖消息）
    this.currentUrl = this.router.url;
    this.isManagement = AdminRoutes.includes(this.currentUrl);
    
    // 订阅后续的路由变化消息
    this._globalSubscription = this.globalService.getMessage().subscribe(async e => {
      if (e.type === "isManagement") {
        this.isManagement = e.value
      }
    })
    
    this.userInfo = JSON.parse(this.storageService.getData('userInfo'));
    const appID = localStorage.getItem('appID');
    if (appID) {
      this.selectedValue = appID
    }
    // 监听路由变化，更新面包屑
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      const url = event.urlAfterRedirects || event.url;
      this.currentUrl = url;
    });
    this.queryApplicationList()
  }
  async queryApplicationList() {
    this.onboardService.getOnboardApplicationList().then((res: any) => {
      this.applicationList = res.data || []
      this.storageService.setData('applicationList', JSON.stringify(this.applicationList))
      this.cdr.detectChanges();
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    })
  }

  handleSelectChange(value: any) {
    localStorage.setItem('appID', value)
    this.globalService.sendMessage(value, 'appID')
  }

  navToManagement() {
    this.globalService.sendMessage(true, 'isManagement')
    this.router.navigate(['/onboard']);
  }

  navToHome() {
    this.router.navigate(['/']);
  }
}
