import { Component, inject, OnInit } from "@angular/core";
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule } from "@angular/forms";
import { NzButtonModule } from "ng-zorro-antd/button";
import { NzFormModule } from "ng-zorro-antd/form";
import { NzGridModule } from "ng-zorro-antd/grid";
import { NzMenuModule } from "ng-zorro-antd/menu";
import { NzSelectModule } from "ng-zorro-antd/select";
import { CommonModule } from "@angular/common";
import { NzIconModule } from 'ng-zorro-antd/icon';
import { ReportChartComponent } from "./reportChart.component";
import { HealthService } from "src/app/service";
import { NzMessageService } from "ng-zorro-antd/message";
import { ReportTableComponent } from "./reportTableData.component";
import { SavingComponent } from "../benefitReporting/saving.component";
import { NzSpinModule } from "ng-zorro-antd/spin";
@Component({
  selector: 'app-reportMgmt',
  templateUrl: './reportMgmt.component.html',
  styleUrls: ['./reportMgmt.component.scss'],
  imports: [
    CommonModule,
    NzGridModule,
    ReactiveFormsModule,
    NzFormModule,
    FormsModule,
    NzSelectModule,
    NzButtonModule,
    NzMenuModule,
    NzIconModule,
    ReportChartComponent,
    ReportTableComponent,
    SavingComponent,
    NzSpinModule,
  ],
})

export class ReportManagementComponent implements OnInit {

  private fb = inject(NonNullableFormBuilder);
  validateForm = this.fb.group({
    report_id: this.fb.control('')
  });
  reportList: any = [{
    value: 'Troubleshooting_Effectiveness',
    label: 'Troubleshooting Effectiveness'
  }, {
    value: 'DummyTag_Cancellation',
    label: 'Dummy Tag Cancellation'
  }, {
    value: 'Battery_Performance',
    label: 'Battery Performance'
  },{
    value: 'Duplicated_Part',
    label: 'Duplicated Part'
  }]
  // reportList: any = []
  reportData: any = {
    weekDailyData: {},
    quarterMonthData: {},
    tableData: {},
  }
  loading: boolean = true
  selectInfo: any = {}

  constructor(
    private healthService: HealthService,
    private message: NzMessageService,
  ) { }

  ngOnInit(): void {
    for (let i = 1; i <= 10; i++) {
      this.reportList.push({
        value: this.reportList.length + i,
        label: `Report${i}`
      });
    }
    this.selectInfo = this.reportList[0]
    this.queryReport()
  }

  queryReport() {
    if (this.selectInfo.label.indexOf('Report') > -1) {
      this.reportData = {
        weekDailyData: null,
        quarterMonthData: null,
        tableData: null,
      }
      this.loading = false
      return
    }
    this.queryWeekDailyChart()
    this.queryQuarterMonthChart()
    this.queryTableData()
  }

  queryWeekDailyChart() {
    this.healthService.getReportChart({
      chart_type: 'Weekly_&_Daily',
      report_name: this.selectInfo.value
    }).then((res: any) => {
      this.reportData.weekDailyData = res.data
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    })
  }

  queryQuarterMonthChart() {
    this.healthService.getReportChart({
      chart_type: 'Quarterly_&_Monthly',
      report_name: this.selectInfo.value
    }).then((res: any) => {
      this.reportData.quarterMonthData = res.data
      this.loading = false
    }).catch((error: any) => {
      this.loading = false
      this.message.error(error.message);
    })
  }

  queryTableData() {
    this.healthService.getReportList({ report_name: this.selectInfo.value }).then((res: any) => {
      this.reportData.tableData = res.data
    }).catch((error: any) => {
      console.log(error)
      this.message.error(error.message);
    })
  }


  handleReportChange(value: any) {
    this.selectInfo = this.reportList.find((item: any) => item.value === value)
    this.loading = true
    this.queryReport()
  }

  handleReportSelect(value: any) {
    this.selectInfo = value
    this.loading = true
    this.queryReport()
  }
}