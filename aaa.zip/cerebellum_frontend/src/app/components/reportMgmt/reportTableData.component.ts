import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule, NgForOf } from '@angular/common';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';

interface DatesItem {
    label: string;
    key: string;
}
interface TableDataItem {
    name: string;
    value: string;
}
@Component({
    selector: 'app-report-table',
    imports: [CommonModule, NgForOf, NzTableModule, NzModalModule, NzButtonModule],
    template: `
        <nz-table  nzBordered [nzData]="reportData.tableData" [nzShowPagination]="false"
              [nzScroll]="{ x: '2000px', y: '300px' }" class="custom-table">
              <thead>
                  <tr>
                      <!-- 第一级表头 -->
                      <th nzWidth="140" nzLeft> </th>
                      <th colspan="5">Last 5 Closed Date (GMT time)</th>
                      <th colspan="3">Last 3 weeks (closed)</th>
                      <th colspan="2">Last 2 months (closed)</th>
                      <th colspan="3">Last 3 Quarters (closed)</th>
                      <th nzWidth="120">QTD</th>
                      <th nzWidth="120">FYTD</th>
                  </tr>

                  <!-- 第二级表头 -->
                  <tr class="second-thead">
                      <th nzWidth="140" nzLeft></th>
                      <ng-container *ngFor="let col of reportData.dateColumns; let i = index">
                          <th>{{ col.label }}</th>
                      </ng-container>
                  </tr>
              </thead>

              <tbody>
                  <tr *ngFor="let row of reportData.tableData">
                      <td nzWidth="140" nzLeft class="left-thead">{{ row.name }}</td>
                      <ng-container *ngFor="let col of reportData.dateColumns; let i = index">
                          <td [class]="row.name === 'attainment%' ? getColumnClass(row.value[i]) : ''" style="text-align: center;">
                              {{ row.value[i] }}
                          </td>
                      </ng-container>
                  </tr>
              </tbody>
        </nz-table>
  `,
    styleUrl: '../benefitReporting/benefitReporting.component.scss',
    standalone: true
})
export class ReportTableComponent {
    @Input() reportData: any = {};

    //   dateColumns: DatesItem[] = [];
    //   tableData: TableDataItem[] = []

    constructor(
        // private healthService: HealthService,
        // private message: NzMessageService,
    ) { }

    ngOnInit(): void {
        // this.reportIndex === 0 ? this.queryTroubleShootingTable() : this.queryDummyTagList()
    }

    queryTroubleShootingTable() {
        // this.healthService.getTroubleShootingList().then((res: any) => {
        //   this.dateColumns = res.data.dateColumns
        //   this.tableData = res.data.tableData
        // }).catch((error: any) => {
        //   console.log(error)
        //   this.message.error(error.message);
        // })
    }

    queryDummyTagList() {
        // this.healthService.getDummyTagList().then((res: any) => {
        //   this.dateColumns = res.data.dateColumns
        //   this.tableData = res.data.tableData
        // }).catch((error: any) => {
        //   console.log(error)
        //   this.message.error(error.message);
        // })
    }

    getColumnClass(value: string | number): string {
        const numValue = typeof value === 'string' ? parseFloat(value) : value;
        if (numValue > 105) return 'bg-blue';
        if (numValue >= 100 && numValue <= 105) return 'bg-gray';
        if (numValue >= 95 && numValue <= 100) return 'bg-green';
        if (numValue >= 90 && numValue <= 95) return 'bg-yellow';
        if (numValue >= 80 && numValue <= 90) return 'bg-amber';
        if (numValue < 80) return 'bg-red';
        return '';
    }

    handleCancel() {
        // this.visibleChange.emit(false);
    }

}
