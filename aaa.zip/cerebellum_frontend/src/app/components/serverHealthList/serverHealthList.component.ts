import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { HealthService } from '../../service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { HealthOptions, ServerTypeOptions } from 'src/app/util/constant';
import { NzTooltipModule } from 'ng-zorro-antd/tooltip';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';

@Component({
  selector: 'app-serverHealthList',
  templateUrl: './serverHealthList.component.html',
  styleUrls: ['./serverHealthList.component.scss'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzGridModule,
    NzFormModule,
    FormsModule,
    NzTableModule,
    NzPaginationModule,
    NzInputModule,
    NzIconModule,
    NzButtonModule,
    NzSelectModule,
    NzTooltipModule,
  ],
})
export class ServerHealthListComponent implements OnInit {
  private fb = inject(NonNullableFormBuilder);
  validateForm = this.fb.group({
    server_name: this.fb.control([]),
    agl_name: this.fb.control([]),
    server_type: this.fb.control(''),
    cpu_health: this.fb.control(''),
    memory_health: this.fb.control(''),
    disk_health: this.fb.control(''),
  });
  tableData: any = {
    list: [],
    pageNum: 1,
    pageSize: 20,
    total: 100
  };
  loading: boolean = true
  serverNameOptions: any = []
  aglNameOptions: any = []
  serverTypeOptions: any = ServerTypeOptions
  healthOptions: any = HealthOptions

  constructor(private healthService: HealthService,
    private message: NzMessageService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.queryServerHealthOptions()
  }

  async queryServerHealthOptions() {
    this.healthService.getServerHealthOptions().then((res: any) => {
      const data = res.data
      this.serverNameOptions = data.ServerName
      this.aglNameOptions = data.AGLName
      this.queryList()
    }).catch((error: any) => {
      this.loading = false
      this.message.error(error.message);
    })
  }

  queryList() {
    this.healthService.getServerHealthList({
      page_size: this.tableData.pageSize,
      page_num: this.tableData.pageNum,
      ...this.validateForm.value
    }).then((res: any) => {
      this.tableData.list = res.data.data || []
      this.tableData.total = res.data.total_count
      this.cdr.markForCheck();
      this.loading = false
    }).catch((error: any) => {
      this.message.error(error.message);
      this.loading = false
    })
  }

  handleSearch() {
    this.loading = true
    this.tableData.pageNum = 1
    this.queryList()
  }

  handlePageIndexChange(page: number) {
    this.tableData.pageNum = page
    this.queryList()
  }

  handleReset() {
    this.validateForm.reset()
    this.tableData.pageNum = 1
    this.queryList()
  }
}