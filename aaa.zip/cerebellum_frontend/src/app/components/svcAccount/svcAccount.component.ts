import { Component } from "@angular/core";

@Component({
  selector: 'app-svcAccount',
  templateUrl: './svcAccount.component.html',
})

export class SvcAccountComponent {
}