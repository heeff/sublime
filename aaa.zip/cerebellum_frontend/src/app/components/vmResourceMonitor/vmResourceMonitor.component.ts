import { Component } from "@angular/core";

@Component({
  selector: 'app-vmResourceMonitor',
  templateUrl: './vmResourceMonitor.component.html',
})

export class VMResourceMonitorComponent {
}