import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { catchError, switchMap, tap } from 'rxjs/operators';
import { TokenService } from "../service/token/token.service";
import { StorageService } from "../service";

@Injectable()
export class APIHttpInterceptor implements HttpInterceptor {


    constructor(private tokenService: TokenService,
        private storageService: StorageService
    ) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        if (!request.headers.get('Authorization')) {
            return next.handle(request).pipe(
                catchError((error) => {
                    return throwError(() => {
                        return error
                    })
                })
            )
        }

        return next.handle(request).pipe(
            tap((response: HttpEvent<any>) => {
                if (response instanceof HttpResponse) {
                    if (response.status === 200) {
                        return response.body
                    }
                }
            }),
            catchError((error) => {
                if (error instanceof HttpErrorResponse) {

                    if (error.status === 401 || error.status === 0) {
                        this.storageService.removeData('token');
                        window.location.reload();
                        // return this.handle401Error(request, next);
                    }
                }
                return throwError(() => {
                    return error
                });
            })
        )
    }

    private handle401Error(request: HttpRequest<any>, next: HttpHandler) {

        return this.tokenService.userLoginAysnc().pipe(
            switchMap((token: any) => {
                this.storageService.setData('token', token.token);
                return next.handle(this.addTokenHeader(request, token.token));
            }),
            catchError((err) => {
                return throwError(() => {
                    return err
                });
            })
        );   
    }

    private addTokenHeader(request: HttpRequest<any>, token: string) {
        return request.clone({ headers: request.headers.set("Authorization", `Bearer ${token}`) });
    }
}
