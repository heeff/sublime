/**
 * Product env
 */
// export const BasicUrl = "https://e2ecma.dell.com/service";
// export const TokenUrl = "https://e2ecma.dell.com/auth";

/**
 * Develop env
 */
// export const TokenUrl = "https://woat.dell.com:456";
// export const BasicUrl = "https://woat.dell.com/apis/v2/prod";
// export const ServiceUrl = "https://woat.dell.com";
// export const LightningUrl = "https://lightning-query-gateway.dat.dell.com";


/**
 * Local env
 */
// export const TokenUrl = "https://cerebellum.dell.com/auth";
export const TokenUrl = "https://cerebellum-dev.dell.com/auth";
export const BasicUrl = "https://cerebellum-backend-temp-pc1.cmapc1kobprod01-p1.kob.dell.com";
// export const BasicUrl = "https://cerebellum-backend-dev-pc1.cmapc1kobprod01-p1.kob.dell.com";
// export const BasicUrl = "https://cerebellum-backend-prod-pc1.cmapc1kobprod01-p1.kob.dell.com";

export function isNotEmpty(value: any) {
    return value != undefined && value != null && value != "";
};

export function DateToLocalTransform(date: Date) {
    let local = new Date(date);
    let gmtHours = (0 - new Date().getTimezoneOffset() / 60);
    let hour = gmtHours % 1;
    let minutes = local.getMinutes() % 60;
    let value;
    if (hour == 0)
        value = local.setHours(local.getHours() + gmtHours);
    else
        value = local.setHours(local.getHours() + Math.trunc(gmtHours), minutes + (hour % 1) * 60);
    let valueDate = new Date(value);
    let timeSpan = 'AM';
    let Y = valueDate.getFullYear().toString().substring(2, 4);
    let M = valueDate.getMonth() + 1 < 10 ? '0' + (valueDate.getMonth() + 1) : valueDate.getMonth() + 1;
    let D = valueDate.getDate() < 10 ? '0' + valueDate.getDate() : valueDate.getDate();
    let h = Hour12Handle(valueDate.getHours())
    let m = valueDate.getMinutes() < 10 ? '0' + valueDate.getMinutes() : valueDate.getMinutes();
    timeSpan = valueDate.getHours() < 12 ? 'AM' : 'PM';
    return `${M}/${D}/${Y} ${h}:${m} ${timeSpan}`;
}

function Hour12Handle(hours: number) {
    if (hours == 0)
        hours = 12;
    if (hours < 10) {
        return '0' + hours;
    } else {
        if (hours <= 12)
            return hours;
        else
            return hours - 12;
    }
}

export const gmtHours = (0 - new Date().getTimezoneOffset() / 60);

export function timeSpanHour(date1: Date, date2: Date) {
    var time1 = new Date(date1).getTime();
    var time2 = new Date(date2).getTime();
    var result = time1 - time2;
    return result / (60 * 60 * 1000);
}

export function formatDate(date: Date, separator: string) {
    if (!date) return
    let year = new Date(date).getFullYear()
    let month: any = new Date(date).getMonth() + 1
    month = month < 10 ? '0' + month : month
    let day: any = new Date(date).getDate()
    day = day < 10 ? '0' + day : day
    return (separator && separator === '/') ? (month + '/' + day + '/' + year) : (year + '-' + month + '-' + day)
}

export function objectToQueryString(obj: any) {
    return Object.keys(obj)
        .filter(key => obj[key] != null && obj[key] !== '') // 过滤掉值为空的键
        .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(obj[key]))
        .join('&')
}
