import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { lastValueFrom } from "rxjs";
import { objectToQueryString } from "./helper.service";

@Injectable()
export class CIDHttp {

    _http: HttpClient;

    constructor(HttpClient: HttpClient) {
        this._http = HttpClient;
    }

    public get<T>(url: string, params?: any): Promise<T> {
        let token: any = window.localStorage.getItem("token");
        if (params !== undefined) {
            const str = objectToQueryString(params)
            url = `${url}?${str}`
        }
        return lastValueFrom(
            this._http.get<T>(url, {
                withCredentials: true,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            })
        )
    }

    public post<T>(url: string, data: any): Promise<T> {
        let token: any = window.localStorage.getItem("token");
        return lastValueFrom(
            this._http.post<T>(url, JSON.stringify(data), {
                withCredentials: true,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            })
        );
    }

    public delete<T>(url: string): Promise<T> {
        let token: any = window.localStorage.getItem("token");
        return lastValueFrom(
            this._http.delete<T>(url, {
                withCredentials: true,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            })
        )
    }
}