import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, timeout } from 'rxjs/operators';

@Injectable()
export class Interceptor implements HttpInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let token: any = window.localStorage.getItem("token");
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            // 'timeout': '30000',
            'withCredentials': 'true'
        })
        // 请求拦截逻辑
        const authReq = req.clone({
            headers
        });

        // 响应拦截逻辑
        return next.handle(authReq).pipe(
            tap(event => {
                if (event instanceof HttpResponse) {
                    // 在这里处理响应数据，例如日志记录或错误处理
                    console.log('Response:', event);
                }
            })
        );
    }
}
