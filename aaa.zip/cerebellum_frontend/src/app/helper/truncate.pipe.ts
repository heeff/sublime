import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'truncate'
})
export class TruncatePipe implements PipeTransform {
  transform(value: string, length: number = 4): string {
    if (!value) return '';
    // 如果字符串长度小于等于指定长度，直接返回原字符串
    if (value.length <= length) return value;
    // 否则返回前N个字符 + 省略号
    return value.substring(0, length) + '...';
  }
}