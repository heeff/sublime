import { Input, Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'UTCToLocal'
})
export class UTCToLocalPipe implements PipeTransform {
    constructor() {}

    transform(value: any): string {
        if(value == null)
            return "";
        let local = new Date(value);
        let gmtHours = (0 - new Date().getTimezoneOffset()/60);
        let hour = gmtHours % 1;
        let minutes = local.getMinutes() % 60;
        if(hour == 0)
            return local.setHours(local.getHours() + gmtHours).toString();
        else
            return local.setHours(local.getHours() + Math.trunc(gmtHours), minutes + (hour % 1)*60).toString();
    }
}
