// services/api.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { objectToQueryString } from 'src/app/helper/helper.service';

@Injectable({
    providedIn: 'root'
})
export class ApiService {
    constructor(private http: HttpClient) { }

    getData(url: string, params?: any): Observable<any> {
        if (params !== undefined) {
            const str = objectToQueryString(params)
            url = `${url}?${str}`
        }
        return this.http.get<any>(url).pipe(
            catchError(this.handleError)
        );
    }

    // public get(url: string, params?: any): Observable<any> {
    //     if (params !== undefined) {
    //         const str = objectToQueryString(params)
    //         url = `${url}?${str}`
    //     }
    //     return this.http.get<any>(url).pipe(
    //         catchError(this.handleError)
    //     );
    // }

    public post(url: string, data: any): Observable<any> {
        return this.http.post<any>(url, JSON.stringify(data)).pipe(
            catchError(this.handleError)
        );
    }

    // 错误处理函数
    private handleError(error: HttpErrorResponse) {
        // 在这里处理错误，例如显示错误消息或日志记录
        console.error('An error occurred:', error.error || error.message || error);
        return throwError('Something bad happened; please try again later.');
    }
}
