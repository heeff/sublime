import { Injectable } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import axios, { AxiosHeaders, AxiosResponse } from 'axios';
import * as _ from 'lodash';
import { TokenUrl } from 'src/app/helper/helper.service';
import { StorageService } from '../storage/storage.service';

@Injectable({
    providedIn: 'root'
})
export class TokenAPIService {
    instance: any
    private router!: Router;
    private inFlightControllers = new Set<AbortController>();

    constructor(private storageService: StorageService, router: Router) {
        this.router = router;
        // data Filtering Whitelist 数据是否需要过滤
        const dataFilterWhiteList = ['work-order/case', '/search_by_asset']
        // token Whitelist 请求是否需要添加token
        const tokenWhiteList = ['work-order/case', '/search_by_asset']
        // timeout Whitelist 请求超时白名单
        const timeoutWhiteList: any = []

        this.instance = axios.create({
            baseURL: TokenUrl,
            headers: {
                'Content-Type': 'application/json'
            },
            withCredentials: true
        })

        const cancelAllInFlightRequests = () => {
            if (this.inFlightControllers.size === 0) return;
            for (const controller of this.inFlightControllers) {
                try {
                    controller.abort();
                } catch {
                    // ignore
                }
            }
            this.inFlightControllers.clear();
        };

        // 全局路由切换时取消所有进行中的请求
        this.router.events.subscribe((event: any) => {
            if (event instanceof NavigationStart) {
                cancelAllInFlightRequests();
            }
        });

        this.instance.interceptors.request.use((config: any) => {
            // 每个请求都创建一个 AbortController，保证路由切换可取消
            const externalSignal: AbortSignal | undefined = config?.signal;
            const controller = new AbortController();
            config.signal = controller.signal;

            config.__abortController = controller;
            this.inFlightControllers.add(controller);

            // 把“调用方 abort”桥接到我们的 controller
            if (externalSignal) {
                const onAbort = () => controller.abort();
                if (externalSignal.aborted) {
                    controller.abort();
                } else {
                    externalSignal.addEventListener('abort', onAbort, { once: true });
                }
                config.__externalAbortSignal = externalSignal;
                config.__externalAbortHandler = onAbort;
            }

            // data Filtering
            if (dataFilterWhiteList.indexOf(config.url) === -1) {
                let data = config.method === 'get' ? config.params : config.data
                // filter: null undefine ''
                if (data !== undefined) {
                    data = _.omitBy(_.assign({}, data), (item:any) => {
                        return _.isUndefined(item) || _.isNull(item) || item === ''
                    }) || {}
                    if (config.method === 'post' || config.method === 'put') {
                        config.data = data
                        config.params = {}
                    }
                    if (config.method === 'get') {
                        config.data = {}
                        config.params = data
                    }
                }
                if (config.id) {
                    config.url = config.url + config.id + '/'
                }
            }
            // timeout
            if (!config.timeout) {
                // config.timeout = timeoutWhiteList.indexOf(config.url) >= 0 ? 30000 : 30000
            }
            // token
            if (tokenWhiteList.indexOf(config.url) === -1) {
                let token: any = window.localStorage.getItem("token");
                config.headers['Authorization'] = `Bearer ${token}`
            }
            return config;
        }, (error: any) => {
            return Promise.reject(error);
        });

        const cleanupController = (config: any) => {
            const controller = config?.__abortController as AbortController | undefined;
            if (controller) {
                this.inFlightControllers.delete(controller);
            }

            const externalSignal = config?.__externalAbortSignal as AbortSignal | undefined;
            const handler = config?.__externalAbortHandler as (() => void) | undefined;
            if (externalSignal && handler) {
                externalSignal.removeEventListener('abort', handler);
            }
        };

        this.instance.interceptors.response.use(
            (response: AxiosResponse) => {
                cleanupController(response.config);
                // 200Request succeeded 201Created succeeded 204Delete succeeded
                if (response && (response.status === 200 || response.status === 201 || response.status === 204)) {
                    if (response.status === 200) {
                        const code = response.data.code
                        if (code !== 0) {
                            // 后三位为619/404 The last three digits are 619 / 404
                            if (String(code).indexOf('619') || String(code).indexOf('404') || String(code).indexOf('401')) {
                                return Promise.reject(response.data)
                            }
                            if (parseInt(code) === 1000) {
                                return response.data
                            }
                            if (parseInt(code) === 5014) {
                                return response.data
                            }
                            if (parseInt(code) === 5015 || parseInt(code) === -1) {
                                return Promise.reject(response.data)
                            }
                            return Promise.reject(response.data)
                        }
                    }
                    return response.data
                }
                return Promise.reject(response.data)
            },
            (error: any) => {
                let url = ''
                if (error.config) {
                    url = error.config.baseURL + '/' + error.config.url
                }

                cleanupController(error?.config);

                // AbortController 取消请求时，静默该错误
                const isAbort =
                    error?.code === 'ERR_CANCELED' ||
                    error?.name === 'CanceledError' ||
                    (typeof error?.message === 'string' && error.message.toLowerCase().includes('canceled'));
                if (isAbort) {
                    return new Promise(() => { })
                }

                if (error.response) {
                    const statusCode = error.response.status
                    // 400字段校验失败 field verification failed
                    // 403用户没有权限 user does not have permission
                    // 404找不到数据 data not found
                    const undefinedArr = [400, 403, 404]
                    if (undefinedArr.indexOf(statusCode) > -1) {
                        return Promise.reject(error.response.data)
                    }
                    // 401token过期 Token expired
                    if (statusCode === 401) {
                        this.storageService.removeData('token');
                        this.instance.cancel && this.instance.cancel()
                        window.location.reload()
                    }

                    const serverArr = [500, 501, 502, 503, 504, 505]
                    if (serverArr.indexOf(statusCode) > -1) {
                        return Promise.reject({ message: url ? 'Server error,please try again later (' + url + ')' : error.response.data })
                    }
                } else {
                    return Promise.reject({ message: url ? 'Api error,please try again later (' + url + ')' : error.response.data })
                }
                // cancel request 取消请求的情况下，终端Promise调用链
                if (axios.isCancel(error)) {
                    return new Promise(() => { })
                }
                const errorStr = error.toString()
                // timeout
                if (errorStr.indexOf('timeout') > -1) {
                    return Promise.reject({ message: url ? 'Request timed out,please try again later (' + url + ')' : error.response.data })
                }
                if (errorStr.indexOf('Network Error') > -1) {
                    this.instance.cancel && this.instance.cancel()
                    window.location.reload()
                }
                return Promise.reject({ message: url ? 'Api error,please try again later (' + url + ')' : error.response.data })
            }
        );
    }
}
