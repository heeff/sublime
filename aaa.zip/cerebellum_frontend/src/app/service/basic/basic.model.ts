export interface Messagebool {
    succeeded: boolean,
    message: string
}

export interface Databool {
    succeeded: boolean,
    message: string,
    data: any
}