import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";

@Injectable()
export class GlobalService {
    private _subject = new Subject<any>();


    sendMessage(value: any, type: string) {
        this._subject.next({value: value, type: type});
    }

    getMessage(): Observable<{value: any, type: string}> {
        return this._subject.asObservable();
    }
}