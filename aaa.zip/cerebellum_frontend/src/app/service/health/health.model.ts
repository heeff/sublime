export interface VulnerabilityReportModel {
    resolved_over_7_days: number,
    resolved_within_7_days: number,
    unresolved_count: number,
    week_name: string,
}

export interface ReportChartModel {
    chart_type: string,
    report_name: string,
}

export interface ReportTableModel {
    report_name: string
}