import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";
import { ReportChartModel, ReportTableModel } from "./health.model";

@Injectable()
export class HealthService {

    _apiUrl: string = "/api/health";

  constructor(private baseAPIService: BaseAPIService) {
  }

  getErrorCodeOptionsList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/splunk_error_code_list`);
  }

  getFilterAPINameByTypeOptionsList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/splunk_api_name_list`,data);
  }

  getErrorCodeList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/splunk_api_error_code_detail`, data);
  }

  getPingOverdueList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/splunk_api_ping_overdue_detail`, data);
  }

  getSQLJobNameOptionsList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/sql_job_name_list`, data);
  }

  getSQLJobList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/sql_job_monitor_detail`, data);
  }

  getServerHealthOptions() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/server_health_filter_list`);
  }

  getServerHealthList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/server_health_detail`,data);
  }

  getAPINameOptionsList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/api_function_list`);
  }

  getAPIBreakdownList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/api_break_down_list`,data);
  }

  getReportChart(data: ReportChartModel) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/report_chart`,data);
  }

  getReportList(data: ReportTableModel) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/report_table`,data);
  }

  // getDummyTagChart(data: any) {
  //   return this.baseAPIService.instance.post(`${this._apiUrl}/dummytag_cancellation_chart`,data);
  // }

  // getDummyTagList() {
  //   return this.baseAPIService.instance.get(`${this._apiUrl}/dummytag_cancellation_table`);
  // }

  getVulnerabilityHealthDevelopers() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/snyk_health_developer`);
  }

  getVulnerabilityHealthList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/snyk_health_list`,data);
  }

  getVulnerabilityHealthChart(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/snyk_health_chart`,data);
  }
}