import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";

@Injectable()
export class IndexService {

    _apiUrl: string = "/api/health";

  constructor(private baseAPIService: BaseAPIService) {
  }

  // infra info
  getInfraInfo() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/infra_health_indicators`);
  }

}