import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";

@Injectable()
export class MapService {

    _apiUrl: string = "/api/health";

  constructor(private baseAPIService: BaseAPIService) {
  }

  getStatusOfMap() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/infra_health_check`);
  }

  changeNode(secondaryNode: string) {
    const payload = {
     category_name: "AIVD",
     secondary_node_name: secondaryNode
    }
    return this.baseAPIService.instance.post(`${this._apiUrl}/sql_switch_nodes`, payload);
  }
}
