// navigation-state.service.ts
import { Injectable } from '@angular/core';

const NAV_KEY = 'NAV_TEMP_DATA';
const NAV_FLAG = 'IS_NAVIGATED';

@Injectable({ providedIn: 'root' })
export class NavigationService {
  // 跳转前调用：保存数据 + 设置标记
  setNavigationData(data: any): void {
    sessionStorage.setItem(NAV_KEY, JSON.stringify(data));
    sessionStorage.setItem(NAV_FLAG, 'true');
  }

  // 目标组件调用：尝试消费数据
  consumeNavigationData(): any | null {
    const flag = sessionStorage.getItem(NAV_FLAG);
    if (flag !== 'true') {
      return null; // 不是从内部导航来的
    }

    // 清除标记（关键！防止刷新后仍有效）
    sessionStorage.removeItem(NAV_FLAG);

    // 读取并清除数据
    const dataStr = sessionStorage.getItem(NAV_KEY);
    sessionStorage.removeItem(NAV_KEY);

    return dataStr ? JSON.parse(dataStr) : null;
  }
}