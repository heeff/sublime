interface TreeNode {
  title: string;
  key: string;
  expanded?: boolean;
  isLeaf?: boolean;
  children?: TreeNode[];
  list?: any[];
}