import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";

@Injectable()
export class OnboardService {

  _apiUrl: string = "/api/onboard";

  constructor(private baseAPIService: BaseAPIService) {
  }

  // Onboard APP List
  getOnboardApplicationList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/app_search_list`);
  }

  // Search By AppID
  searchApplicationID(id: string) {
    return this.baseAPIService.instance.get(`${this._apiUrl}/app_search_by_id/${id}`);
  }

  // Add Onboard
  onboardApplicationAdd(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/app_onboard`, data);
  }

  // Onboard List
  getOnboardList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/app_details_onboard_list`);
  }

  // Delete Onboard
  deleteOnboardAPP(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/app_offboard`, data);
    // return this._http.post<any>(`${BasicUrl}${this._apiUrl}/app_offboard`, data);
  }

  // instanceList
  getInstanceList(id: string) {
    return this.baseAPIService.instance.get(`${this._apiUrl}/app_instance_list_query/${id}`);
    // return this._http.get<any>(`${BasicUrl}${this._apiUrl}/app_instance_list_query/${id}`);
  }

  // instanceTableList
  getInstanceTableList(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/service_list_query`, data);
  }

  getInstanceInfo(id: string) {
    return this.baseAPIService.instance.get(`${this._apiUrl}/app_instance_detail_query/${id}`);
    // return this._http.get<any>(`${BasicUrl}${this._apiUrl}/app_instance_detail_query/${id}`);
  }

  // getWorkloadTree
  getWorkloadTree(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/kob_workload_list_query`, data);
  }

  // getKobAvailableResource
  getKobAvailableResource(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/kob_available_resource`, data);
  }

  // adjustWorkloadResource
  adjustWorkload(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/kob_workload_resource_adjust`, data);
  }

  // pod restart
  restartPod(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/kob_pod_restart`, data);
  }

  getFailPodCount(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/kob_failed_or_unknown_pods`, data);
  }

}
