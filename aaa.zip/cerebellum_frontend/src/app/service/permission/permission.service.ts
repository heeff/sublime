import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";

@Injectable()
export class PermissionService {

    _apiUrl: string = "/api/agent_access";

  constructor(private baseAPIService: BaseAPIService) {
  }

  // Permission List
  getPermissionList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/permissions_list`);
  }

  // Add Permission
  addPermission(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/permissions_add`,data);
  }

  // Update Permission
  updatePermission(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/permissions_update`,data);
  }

  // Delete Permission
  deletePermission(data: any) {
    return this.baseAPIService.instance.post(`${this._apiUrl}/permissions_delete`,data);
  }
}