import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";

@Injectable()
export class ReportService {

  _apiUrl: string = "/api/jira";

  constructor(private baseAPIService: BaseAPIService) {
  }

  getReport(period: string, application: string[]) {
    const payload = {
      period: period,
      application: application
    }
    return this.baseAPIService.instance.post(`${this._apiUrl}/report_query`, payload);
  }

  getReportBySprint(sprint: number[], application: string[]) {
    const payload = {
      sprint_id: sprint,
      application: application
    }
    return this.baseAPIService.instance.post(`${this._apiUrl}/report_query`, payload);
  }

  sprintList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/sprint_list`);
  }
}
