import { Injectable } from "@angular/core";

@Injectable()
export class StorageService {

  setData(key:string,data: any): void {
    window.localStorage.setItem(key, data)
  }

  getData(key:string): any {
    return window.localStorage.getItem(key)
  }

  removeData(key:string): void {
    window.localStorage.removeItem(key)
  }
}