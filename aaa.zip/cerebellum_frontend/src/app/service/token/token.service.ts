import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { lastValueFrom } from "rxjs";
import { TokenUrl } from "src/app/helper/helper.service";

@Injectable()
export class TokenService { 
    _apiUrl: string = "/api/security";
    _http: HttpClient;

    constructor (http: HttpClient) {
        this._http = http;
    }

    // refreshTokenAsync() {
    //    return this._http.get(`${TokenUrl}${this._apiUrl}/token`, { withCredentials: true });
    // }

    userLoginAysnc(): any {
        return lastValueFrom(this._http.get(`${TokenUrl}${this._apiUrl}/token`, { withCredentials: true }));
    }

    async saveTokenAsync() {
        let token = await this.userLoginAysnc();
        window.localStorage.setItem("token", token.token);
        return token.token;
    }

    saveToken(token: any) {
        window.localStorage.setItem("token", token.token);
    }
}