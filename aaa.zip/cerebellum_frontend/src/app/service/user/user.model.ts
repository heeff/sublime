export interface EpiUserModel {
    User_NT: string,
    User_Badge: string
}