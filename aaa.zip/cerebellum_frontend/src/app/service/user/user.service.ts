import { Injectable } from "@angular/core";
import { BaseAPIService } from "../api/baseAPI.service";

@Injectable()
export class UserService {

    _apiUrl: string = "/api/agent_access";

  constructor(private baseAPIService: BaseAPIService) {
  }

  getUserInfo() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/permissions`);
  }

  // EPI List
  getEPIList() {
    return this.baseAPIService.instance.get(`${this._apiUrl}/epi_list`);
  }

}