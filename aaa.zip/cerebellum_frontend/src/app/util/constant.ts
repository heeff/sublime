import { MenuItem } from "../components";

// AdminRoutes
export const AdminRoutes = ['/permission', '/onboard']

// Menu
export const menuItems: MenuItem[] = [
  // UserPage
  {
    key: 'home',
    icon: 'area-chart',
    label: 'Home',
    isAdmin: false,
    route: '/index',
  },
  {
    key: 'main-mgmt',
    icon: 'user',
    label: 'Main Mgmt',
    isAdmin: false,
    children: [
      { key: 'sqljob-monitor', label: 'SQL Job Monitor', route: '/sqlJobMonitor' },
      { key: 'svc-account-mgmt', label: 'Svc Account Mgmt', route: '/svcAccountMgmt' },
      { key: 'api-health-dashboard', label: 'API Health Dashboard', route: '/apiHealthDashboard' },
      { key: 'api-failure-distribution', label: 'API Failure Distribution', route: '/apiFailureDistribution' },
      { key: 'server-health-dashboard', label: 'Server Health', route: '/serverHealth' },
      { key: 'vulnerability-mgmt', label: 'Vulnerability Mgmt', route: '/vulnerabilityMgmt' },
      { key: 'report-mgmt', label: 'Report Mgmt', route: '/reportMgmt' },
    ]
  },
  {
    key: 'infra-mgmt',
    icon: 'setting',
    label: 'Infra Mgmt',
    isAdmin: false,
    children: [
      { key: 'kob-monitor', label: 'KOB Monitor', route: '/infraManagement' },
      { key: 'vm-resource-monitor', label: 'VM Resource Monitor', route: '/vmResourceMonitor' }
    ]
  },
  // ManagementPage
  {
    key: 'app-onboard',
    icon: 'unordered-list',
    label: 'APP Onboard',
    route: '/onboard',
    isAdmin: true,
  },
  {
    key: 'permission',
    icon: 'group',
    label: 'Permission',
    route: '/permission',
    isAdmin: true,
  },

]

export const RoleList = [{
  label: 'RO',
  value: 1
}, {
  label: 'RW',
  value: 2
}, {
  label: 'Admin',
  value: 9999
}]

export const Threshold = 100
export const BenefitTabList = ['Wk & D', 'Q & M']

export const AgePeriodOptions = ['recent 12 hours', 'recent 24 hours', 'recent 72hours']
export const APITypeOptions = [{
  label: 'Owned',
  value: 'Owned API'
}, {
  label: 'Dependency',
  value: 'Dependency API'
}]
export const ExecutionAgeOptions = ['10-15s', ' 16-20s', ' 21-25s', '26-30s', '> 30s']
export const JobStatusOptions = ['Running', 'Disabled', 'Succeeded', 'Failed', 'Canceled', 'Retry', 'Never run']
export const JobRunOptions = ['All', 'Last run']
export const ServerTypeOptions = ['SQL Server', 'Windows']
export const HealthOptions = ['Health', 'Unhealth']

export const PodErrorStatus = [
  'CrashLoopBackOff',
  'CreateContainerError',
  'Error',
  'OOMKilled',
  'ContainerCannotRun',
  'DeadlineExceeded',
  'Evicted',
  'ImagePullBackOff',
  'ErrImagePull',
  'CreateContainerConfigError',
]

export const PodStatusTooltip = [
  {
    status:'Pending',
    type:'success',
    text:'Created but not scheduled or image is being pulled'
  },{
    status:'Running',
    type:'success',
    text:'Scheduled with at least one container running'
  },{
    status:'Succeeded',
    type:'success',
    text:'All containers exited successfully (Job scenario)'
  },{
    status:'Failed',
    type:'warning',
    text:'All containers terminated, with at least one failure'
  },{
    status:'Unknown',
    type:'warning',
    text:'Node lost, status unknown'
  },{
    status: 'Error',
    type:'warning',
    text: 'Container exited with a non-zero exit code'
  },
  {
    status: 'CrashLoopBackOff',
    type:'warning',
    text: 'Container repeatedly crashes and Kubernetes is waiting to restart it'
  },
  {
    status: 'CreateContainerError',
    type:'warning',
    text: 'Failed to create the container due to runtime configuration issues'
  },
  {
    status: 'OOMKilled',
    type:'warning',
    text: 'Container exceeded its memory limit and was terminated'
  },
  {
    status: 'ContainerCannotRun',
    type:'warning',
    text: 'Invalid container configuration (e.g., invalid command or missing image)'
  },
  {
    status: 'DeadlineExceeded',
    type:'warning',
    text: 'The Pod exceeded its active deadline'
  },
  {
    status: 'Evicted',
    type:'warning',
    text: 'Removed from the node due to resource pressure (e.g., disk or memory)'
  },
  {
    status: 'ImagePullBackOff',
    type:'warning',
    text: 'Failed to pull the image; Kubernetes will retry with exponential backoff'
  },
  {
    status: 'ErrImagePull',
    type:'warning',
    text: 'Failed to pull the image (e.g., image not found or unauthorized)'
  },
  {
    status: 'CreateContainerConfigError',
    type:'warning',
    text: 'Failed to create container due to missing or invalid ConfigMap/Secret'
  }
]