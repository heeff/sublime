import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";
import { NzTreeNodeOptions } from "ng-zorro-antd/tree";

/**
 * remove spaces from a string去掉字符串的空格
 * @param {string} str
 * @return {string}
 */
export const stringTrim = (str: string) => {
  return str.replace(/\s+/g, '')
}

export const getWeekList = () => {
  // let date: any = new Date()
  // date = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  // date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
  // let yearStart: any = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  // let weekNo = Math.ceil(((date - yearStart) / 86400000 + 1) / 7);
  const weekList = [...Array(52).keys()].map(i => i + 1);
  return weekList;
}

/**
 * Judging Japanese full-width half-width length 判断日文全角半角长度
 * @param {string} str incoming string 传入的参数
 * @return {string} output length 输出长度
 */
export const calcUTFByte = (str: string) => {
  if (!str) return 0
  let length = 0
  for (var i = 0; i < str.length; i++) {
    var temp = str.charCodeAt(i)
    if (temp >= 0 && temp <= 254) {
      // The following are full-width characters within 0-255 以下是0-255之内为全角的字符
      if (
        temp === 162 ||
        temp === 163 ||
        temp === 167 ||
        temp === 168 ||
        temp === 171 ||
        temp === 172 ||
        temp === 175 ||
        temp === 176 ||
        temp === 177 ||
        temp === 180 ||
        temp === 181 ||
        temp === 182 ||
        temp === 183 ||
        temp === 184 ||
        temp === 187 ||
        temp === 215 ||
        temp === 247
      ) {
        length += 2
      }
      length++
    } else if (temp >= 65377 && temp <= 65439) {
      if (temp === 65381) {
        length += 2
      }
      length++
    } else {
      length += 2
    }
  }
  return length
}

export const filterApplication = (inputValue: string, option: any): boolean => {
  if (!option) return false;

  // 获取当前选项的App_Name和App_Number
  const appName = option.nzLabel.toLowerCase(); // 包含名称和编号的完整标签
  const appNumber = option.nzValue.toLowerCase(); // 编号

  // 转换输入值为小写，忽略大小写
  const input = inputValue.toLowerCase();

  // 同时检查名称和编号是否包含输入值
  return appName.includes(input) || appNumber.includes(input);
}


export interface TargetNodeFilter {
  targetTitle: string; // 要匹配的节点 title
  targetEnv: string;   // 第一层环境名（如 'PROD'）
}

/**
 * 查找目标节点：
 * - 有 filter：在 targetEnv 子树中找 title 匹配的第一个节点（可非叶子）
 * - 无 filter：在第一个 env 子树中找第一个 *叶子* 节点
 */
export const findFirstLeafNode = (
  nodes: NzTreeNodeOptions[],
  filter?: TargetNodeFilter
): {
  key: string;
  node: NzTreeNodeOptions;
  selectedKeys: string[];
} | null => {
  if (!nodes || nodes.length === 0) return null;

  if (filter) {
    const { targetTitle, targetEnv } = filter;

    // Step 1: 在第一层找 env 节点
    const envNode = nodes.find(node => node.title === targetEnv);
    if (!envNode) return null;

    // Step 2: 在其子树中查找 title 匹配的第一个节点（任意类型）
    const matched = findNodeByTitleInSubtree(envNode.children || [], targetTitle);
    if (matched) {
      const key = String(matched.key);
      return {
        key,
        node: { ...matched },
        selectedKeys: [key]
      };
    }
    return null;
  } else {
    // 无 filter：默认选中第一个 env 子树中的第一个 *叶子* 节点
    const firstEnv = nodes[0];
    const leaf = findFirstLeafInSubtree(firstEnv);
    if (leaf) {
      const key = String(leaf.key);
      return {
        key,
        node: { ...leaf },
        selectedKeys: [key]
      };
    }
    return null;
  }
};

// 🔍 在子树中查找 title 匹配的第一个节点（DFS，不区分是否叶子）
function findNodeByTitleInSubtree(
  children: NzTreeNodeOptions[],
  targetTitle: string
): NzTreeNodeOptions | null {
  const stack = [...children];
  while (stack.length > 0) {
    const node = stack.shift()!;
    if (node.title === targetTitle) {
      return node; // 找到即返回，不管是不是叶子
    }
    if (node.children?.length) {
      stack.unshift(...node.children); // DFS
    }
  }
  return null;
}

// 🍃 在子树中查找第一个 *叶子* 节点（必须无子节点或 children 为空）
function findFirstLeafInSubtree(root: NzTreeNodeOptions): NzTreeNodeOptions | null {
  const stack = [...(root.children || [])];
  while (stack.length > 0) {
    const node = stack.shift()!;
    const isLeaf = !node.children || node.children.length === 0;
    if (isLeaf) {
      return node;
    }
    if (node.children?.length) {
      stack.unshift(...node.children); // DFS
    }
  }
  return null;
}

export const findAllKeysByTitle = (nodes: any[], targetTitle: string): string[] => {
  const result: string[] = [];

  const traverse = (list: any[]) => {
    for (const node of list) {
      if (node.title === targetTitle) {
        result.push(node.key);
      }
      if (node.children && Array.isArray(node.children)) {
        traverse(node.children); // 继续递归子节点
      }
    }
  };

  traverse(nodes);
  return result;
};


export const processTreeNodes = (
  nodes: NzTreeNodeOptions[],
  options: {
    targetTitles?: string[];   // 用于 isLink（按 title 匹配）
    targetKeys?: string[];     // 用于控制展开（按 key 匹配）
  } = {}
): NzTreeNodeOptions[] => {
  const { targetTitles = [], targetKeys = [] } = options;

  const process = (
    nodeList: NzTreeNodeOptions[],
    parentIsTargetForKey: boolean = false // 仅用于 expanded 控制
  ): NzTreeNodeOptions[] => {
    return nodeList.map(node => {
      const newNode = { ...node };

      // ========== 1. 控制 expanded 状态（基于 key）==========
      if (parentIsTargetForKey) {
        newNode.expanded = false; // 目标 key 节点的直接子节点不展开
      } else {
        newNode.expanded = true;  // 其他默认展开
      }

      // 判断当前节点是否是 "目标 key 节点"（用于控制下一层 expanded）
      const isCurrentTargetForKey = targetKeys.includes(String(newNode.key));

      // ========== 2. 处理 isLink（基于 title）==========
      // 如果当前节点的 title 在 targetTitles 中，且有子节点 → 给直接子节点加 isLink
      if (
        targetTitles.length > 0 &&
        targetTitles.includes(newNode.title as string) &&
        Array.isArray(newNode.children)
      ) {
        newNode.children = newNode.children.map(child => ({
          ...child,
          isLink: true
        }));
      }

      // ========== 3. 递归处理子节点 ==========
      if (newNode.children && newNode.children.length > 0) {
        // 注意：即使上面已 map 过 children（加 isLink），仍需递归设置 expanded 状态
        newNode.children = process(newNode.children, isCurrentTargetForKey);
      }

      return newNode;
    });
  };

  return process(nodes);
};


// 辅助函数：根据 key 递归查找节点
export const findNodeByKey = (nodes: NzTreeNodeOptions[], key: string): NzTreeNodeOptions | null => {
  for (const node of nodes) {
    if (node.key === key) {
      return node;
    }
    if (node.children?.length) {
      const found = findNodeByKey(node.children, key);
      if (found) return found;
    }
  }
  return null;
}

export const setAllExpanded = (nodes: NzTreeNodeOptions[]): NzTreeNodeOptions[] => {
  return nodes.map(node => {
    const newNode = { ...node };
    newNode.expanded = true; // 默认展开
    // 如果有子节点，递归处理
    if (newNode.children && newNode.children.length > 0) {
      newNode.children = setAllExpanded(newNode.children);
    }
    return newNode;
  });
}


export const getEnvFromKey = (key: string) => {
  // 匹配 "node-数字" 的模式，提取第一个数字
  const match = key.match(/^node-(\d+)/);

  if (match) {
    const firstNumber = match[1]; // 字符串形式的数字，如 "0", "1", "12"
    return firstNumber === '0' ? 'prod' : 'nonprod';
  }

  // 如果格式不符合，默认视为 nonprod（或抛出错误）
  return 'nonprod';
}

export function rangeValidator(min: number, max: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    // 如果值为空，通常由 required 验证处理，这里不报错
    if (value === null || value === undefined || value === '') {
      return null;
    }

    const numValue = Number(value);

    // 检查是否为有效数字
    if (isNaN(numValue)) {
      return { range: { min, max, actual: value } };
    }

    // 检查范围
    if (numValue <= min || numValue >= max) {
      return { range: { min, max, actual: numValue } };
    }

    return null;
  };
}

// 根据 error code 分配颜色
  export function getColorForErrorCode(code: string): string {
    const codeNum = parseInt(code)
    
    // 2xx 成功状态码 - 绿色系
    if (codeNum >= 200 && codeNum < 300) {
      if (code === '200') return '#52c41a' // 成功 - 绿色
      return '#73d13d' // 其他2xx - 浅绿色
    }
    
    // 3xx 重定向状态码 - 蓝色系
    if (codeNum >= 300 && codeNum < 400) {
      return '#2db7f5' // 蓝色
    }
    
    // 4xx 客户端错误 - 橙色/黄色系
    if (codeNum >= 400 && codeNum < 500) {
      if (code === '400') return '#ffe869' // 请求错误 - 橙色
      if (code === '401') return '#ffd00c' // 未授权 - 黄色
      if (code === '403') return '#f9c535' // 禁止访问 - 黄色
      if (code === '404') return '#fff200' // 未找到 - 橙色
      if (code === '422') return '#f7b236' 
      if (code === '423') return '#fa8c16'
      return '#ffa940' // 其他4xx - 浅橙色
    }
    
    // 5xx 服务器错误 - 红色系
    if (codeNum >= 500 && codeNum < 600) {
      if (code === '500') return '#f5222d' // 服务器错误 - 红色
      if (code === '502') return '#ff4d4f' // 网关错误 - 深红色
      if (code === '503') return '#ff7875' // 服务不可用 - 浅红色
      return '#ff4d4f' // 其他5xx - 红色
    }
    
    // 其他状态码 - 使用随机亮色
    return generateRandomBrightColor()
  }

  // 生成随机亮色（避免太暗或太灰）
  export function generateRandomBrightColor(): string {
    // 使用 HSL 更容易控制亮度和饱和度
    const hue = Math.floor(Math.random() * 360);
    const saturation = 70 + Math.floor(Math.random() * 30); // 70%～100%
    const lightness = 40 + Math.floor(Math.random() * 20);  // 40%～60%
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  }
