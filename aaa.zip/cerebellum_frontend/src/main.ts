import { bootstrapApplication } from '@angular/platform-browser';
import { importProvidersFrom } from '@angular/core';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClientXsrfModule, provideHttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import * as AllIcons from '@ant-design/icons-angular/icons';

import { AppComponent } from './app/app.component';
import { routes } from './app/app-routing.module';
import { APIHttpInterceptor } from './app/helper/api.httpintercept';
import { CIDHttp } from './app/helper/http';
import {
  ApiService,
  BaseAPIService,
  GlobalService,
  OnboardService,
  StorageService,
  TokenAPIService,
  TokenService,
  PermissionService,
  UserService,
  IndexService,
  HealthService,
  MapService,
} from './app/service';
import { provideEchartsCore } from 'ngx-echarts';
import * as echarts from 'echarts/core';

bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes),
    provideAnimations(),
    provideEchartsCore({
      echarts
    }),
    importProvidersFrom(
      FormsModule,
      ReactiveFormsModule,
      NzIconModule.forRoot(Object.values(AllIcons) as any)
    ),
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    { provide: HTTP_INTERCEPTORS, useClass: APIHttpInterceptor, multi: true },
    // app-wide services
    provideHttpClient(),
    BaseAPIService,
    TokenAPIService,
    ApiService,
    CIDHttp,
    TokenService,
    StorageService,
    GlobalService,
    OnboardService,
    PermissionService,
    UserService,
    IndexService,
    HealthService,
    MapService
  ],
}).catch((err: unknown) => console.error(err));
